/**
 * Animation utilities for improved performance and visual appeal
 */

interface AnimationOptions {
  duration?: number
  easing?: string
  delay?: number
  iterations?: number
  direction?: "normal" | "reverse" | "alternate" | "alternate-reverse"
  fill?: "none" | "forwards" | "backwards" | "both"
}

/**
 * Creates a Web Animation with performance optimizations
 */
export function createOptimizedAnimation(
  element: HTMLElement,
  keyframes: Keyframe[],
  options: AnimationOptions = {},
): Animation | null {
  if (!element || !window.Animation) {
    console.warn("Animation API not supported or element not found")
    return null
  }

  // Default options for smooth animations
  const defaultOptions: AnimationOptions = {
    duration: 300,
    easing: "cubic-bezier(0.4, 0, 0.2, 1)", // Material Design standard easing
    fill: "both",
  }

  const animationOptions = { ...defaultOptions, ...options }

  try {
    // Add will-change to optimize rendering performance
    element.style.willChange = getWillChangeProperties(keyframes)

    // Create the animation
    const animation = element.animate(keyframes, animationOptions)

    // Clean up will-change after animation completes
    animation.onfinish = () => {
      element.style.willChange = "auto"
    }

    return animation
  } catch (error) {
    console.error("Error creating animation:", error)
    // Reset will-change in case of error
    element.style.willChange = "auto"
    return null
  }
}

/**
 * Determines appropriate will-change properties based on keyframes
 */
function getWillChangeProperties(keyframes: Keyframe[]): string {
  const properties = new Set<string>()

  // Extract animated properties from keyframes
  keyframes.forEach((keyframe) => {
    Object.keys(keyframe).forEach((key) => {
      // Skip non-CSS properties
      if (key !== "offset" && key !== "easing" && key !== "composite") {
        // Convert camelCase to kebab-case for CSS properties
        const cssProperty = key.replace(/([A-Z])/g, "-$1").toLowerCase()
        properties.add(cssProperty)
      }
    })
  })

  // Limit to most important properties for performance
  const importantProperties = ["transform", "opacity"]
  const filteredProperties = Array.from(properties).filter(
    (prop) => importantProperties.includes(prop) || importantProperties.some((p) => prop.includes(p)),
  )

  return filteredProperties.length > 0 ? filteredProperties.join(", ") : "auto"
}

/**
 * Creates a smooth scroll animation
 */
export function smoothScrollTo(
  element: HTMLElement,
  options: { top?: number; left?: number; behavior?: ScrollBehavior } = {},
): void {
  const { top, left, behavior = "smooth" } = options

  try {
    // Use native smooth scrolling if available
    element.scrollTo({
      top,
      left,
      behavior,
    })
  } catch (error) {
    // Fallback for browsers that don't support smooth scrolling
    if (top !== undefined) element.scrollTop = top
    if (left !== undefined) element.scrollLeft = left
  }
}

/**
 * Optimized version of requestAnimationFrame that batches updates
 */
export const optimizedRAF = (() => {
  const callbacks: Array<(time: number) => void> = []
  let scheduled = false

  function loop(time: number) {
    scheduled = false
    const callbacksToRun = [...callbacks]
    callbacks.length = 0

    callbacksToRun.forEach((callback) => callback(time))
  }

  return (callback: (time: number) => void): void => {
    callbacks.push(callback)

    if (!scheduled) {
      scheduled = true
      requestAnimationFrame(loop)
    }
  }
})()

