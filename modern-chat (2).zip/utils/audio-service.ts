/**
 * A simple audio service that uses HTML5 Audio API
 */

// Track the current audio element to ensure only one plays at a time
let currentAudio: HTMLAudioElement | null = null

// Simple function to stop any currently playing audio
export function stopCurrentAudio(): void {
  if (currentAudio) {
    currentAudio.pause()
    currentAudio.currentTime = 0
    currentAudio = null
  }
}

// Simple function to play a beep sound to indicate an action
export function playBeep(): Promise<void> {
  return new Promise((resolve) => {
    stopCurrentAudio()

    // Create a simple beep using AudioContext
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.type = "sine"
      oscillator.frequency.value = 800 // frequency in hertz
      gainNode.gain.value = 0.1 // volume control

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.start()
      setTimeout(() => {
        oscillator.stop()
        resolve()
      }, 200) // short beep duration
    } catch (error) {
      console.error("Error playing beep:", error)
      resolve() // Resolve anyway to prevent hanging
    }
  })
}

// Simple function to indicate text is being processed
export async function indicateTextProcessing(): Promise<void> {
  // Play a simple beep to indicate processing
  await playBeep()
}

