"use client"

/**
 * Utilities for batching React state updates to improve performance
 */

import { useState, useCallback, useRef, useEffect } from "react"

/**
 * Custom hook for batched state updates
 * This reduces re-renders by batching multiple state updates together
 */
export function useBatchedState<T>(initialState: T): [T, (updates: Partial<T>) => void, (newState: T) => void] {
  const [state, setState] = useState<T>(initialState)
  const pendingUpdatesRef = useRef<Partial<T>>({})
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Apply batched updates
  const applyUpdates = useCallback(() => {
    if (Object.keys(pendingUpdatesRef.current).length > 0) {
      setState((prevState) => ({
        ...prevState,
        ...pendingUpdatesRef.current,
      }))
      pendingUpdatesRef.current = {}
    }
  }, [])

  // Queue updates to be applied in batch
  const queueUpdate = useCallback(
    (updates: Partial<T>) => {
      // Merge with pending updates
      pendingUpdatesRef.current = {
        ...pendingUpdatesRef.current,
        ...updates,
      }

      // Schedule batch update
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }

      timeoutRef.current = setTimeout(() => {
        applyUpdates()
        timeoutRef.current = null
      }, 0) // Use microtask timing for batching
    },
    [applyUpdates],
  )

  // Set state immediately (bypass batching)
  const setStateImmediate = useCallback((newState: T) => {
    // Clear any pending updates
    pendingUpdatesRef.current = {}

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
      timeoutRef.current = null
    }

    setState(newState)
  }, [])

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  return [state, queueUpdate, setStateImmediate]
}

/**
 * Batches multiple function calls that occur within a specified time window
 * Useful for event handlers that might be called rapidly (e.g., scroll, resize)
 */
export function batchCalls<T extends (...args: any[]) => void>(fn: T, wait = 100): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null
  let batched: { args: Parameters<T>; timestamp: number }[] = []

  return (...args: Parameters<T>): void => {
    const now = Date.now()

    // Add to batch
    batched.push({ args, timestamp: now })

    // Clear existing timeout
    if (timeout) {
      clearTimeout(timeout)
    }

    // Schedule processing
    timeout = setTimeout(() => {
      // Process only the most recent call
      const mostRecent = batched.reduce((latest, current) => (current.timestamp > latest.timestamp ? current : latest))

      // Execute with the most recent arguments
      fn(...mostRecent.args)

      // Clear batch
      batched = []
      timeout = null
    }, wait)
  }
}

/**
 * Creates a function that executes at most once per animation frame
 * Useful for optimizing functions that update the DOM
 */
export function rafThrottle<T extends (...args: any[]) => void>(fn: T): (...args: Parameters<T>) => void {
  let rafId: number | null = null
  let lastArgs: Parameters<T> | null = null

  return (...args: Parameters<T>): void => {
    // Store the most recent arguments
    lastArgs = args

    // If we already have a frame scheduled, don't schedule another
    if (rafId !== null) return

    // Schedule execution on next animation frame
    rafId = requestAnimationFrame(() => {
      if (lastArgs) {
        fn(...lastArgs)
      }
      rafId = null
    })
  }
}

