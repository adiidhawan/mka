/**
 * Centralized error handling and logging utility
 */
import { toast } from "@/components/ui/use-toast"

type ErrorSeverity = "low" | "medium" | "high" | "critical"

interface ErrorOptions {
  severity?: ErrorSeverity
  context?: Record<string, any>
  shouldReport?: boolean
  showToast?: boolean
}

/**
 * Handles and logs errors with appropriate severity and context
 */
export function handleError(error: Error, options: ErrorOptions = {}) {
  const {
    severity = "medium",
    context = {},
    shouldReport = process.env.NODE_ENV === "production",
    showToast = true,
  } = options

  // Format error details
  const errorDetails = {
    message: error.message,
    stack: error.stack,
    name: error.name,
    severity,
    timestamp: new Date().toISOString(),
    context,
    environment: process.env.NODE_ENV,
  }

  // Log error based on severity
  switch (severity) {
    case "low":
      console.info("Non-critical error:", errorDetails)
      break
    case "medium":
      console.warn("Warning:", errorDetails)
      break
    case "high":
    case "critical":
      console.error(`${severity.toUpperCase()} ERROR:`, errorDetails)
      break
    default:
      console.error("Unexpected error:", errorDetails)
  }

  // Show toast notification if enabled
  if (showToast && typeof window !== "undefined") {
    const userMessage = getUserFriendlyMessage(error, severity)
    toast({
      title: severity === "critical" ? "Critical Error" : "Error",
      description: userMessage,
      variant: "destructive",
      duration: 5000,
    })
  }

  // Report error to monitoring service in production
  if (shouldReport) {
    // In a real app, you would send this to your error monitoring service
    // Example: reportToErrorMonitoring(errorDetails)
  }

  // Return formatted error for UI display if needed
  return {
    message: getUserFriendlyMessage(error, severity),
    details: errorDetails,
  }
}

/**
 * Converts technical error messages to user-friendly messages
 */
function getUserFriendlyMessage(error: Error, severity: ErrorSeverity): string {
  // Network errors
  if (error.message.includes("network") || error.message.includes("fetch")) {
    return "Unable to connect to the server. Please check your internet connection and try again."
  }

  // Authentication errors
  if (error.message.includes("auth") || error.message.includes("token") || error.message.includes("permission")) {
    return "Your session may have expired. Please sign in again."
  }

  // For critical errors
  if (severity === "critical") {
    return "A critical error has occurred. Our team has been notified and is working on a fix."
  }

  // Default message
  return "Something went wrong. Please try again later."
}

/**
 * Creates a safe version of a function that catches and handles errors
 */
export function createSafeFunction<T extends (...args: any[]) => any>(
  fn: T,
  errorHandler?: (error: Error) => void,
): (...args: Parameters<T>) => ReturnType<T> | undefined {
  return function safeFn(...args: Parameters<T>): ReturnType<T> | undefined {
    try {
      return fn(...args)
    } catch (error) {
      const handledError = handleError(error instanceof Error ? error : new Error(String(error)))

      if (errorHandler) {
        errorHandler(error instanceof Error ? error : new Error(String(error)))
      }

      console.error("Error in safe function:", handledError)
      return undefined
    }
  }
}

