/**
 * Utility for monitoring and optimizing performance
 */

// Track component render times
const renderTimes: Record<string, number[]> = {}

/**
 * Tracks the render time of a component
 * @param componentName The name of the component
 * @param startTime The start time of the render
 */
export function trackRender(componentName: string, startTime: number) {
  const renderTime = performance.now() - startTime

  if (!renderTimes[componentName]) {
    renderTimes[componentName] = []
  }

  renderTimes[componentName].push(renderTime)

  // Keep only the last 10 render times
  if (renderTimes[componentName].length > 10) {
    renderTimes[componentName].shift()
  }

  // Log slow renders in development
  if (process.env.NODE_ENV === "development" && renderTime > 16) {
    console.warn(`Slow render detected in ${componentName}: ${renderTime.toFixed(2)}ms`)
  }
}

/**
 * Gets the average render time for a component
 * @param componentName The name of the component
 * @returns The average render time in milliseconds
 */
export function getAverageRenderTime(componentName: string): number {
  if (!renderTimes[componentName] || renderTimes[componentName].length === 0) {
    return 0
  }

  const sum = renderTimes[componentName].reduce((acc, time) => acc + time, 0)
  return sum / renderTimes[componentName].length
}

/**
 * Measures the execution time of a function
 * @param fn The function to measure
 * @param args The arguments to pass to the function
 * @returns The result of the function and the execution time
 */
export function measureExecutionTime<T, Args extends any[]>(
  fn: (...args: Args) => T,
  ...args: Args
): { result: T; executionTime: number } {
  const start = performance.now()
  const result = fn(...args)
  const executionTime = performance.now() - start

  return { result, executionTime }
}

/**
 * Creates a throttled function that only invokes the provided function
 * at most once per every specified wait milliseconds
 */
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  wait: number,
): (...args: Parameters<T>) => ReturnType<T> | undefined {
  let lastCall = 0
  let lastResult: ReturnType<T> | undefined

  return function throttled(...args: Parameters<T>): ReturnType<T> | undefined {
    const now = Date.now()
    if (now - lastCall >= wait) {
      lastCall = now
      lastResult = func(...args)
    }
    return lastResult
  }
}

