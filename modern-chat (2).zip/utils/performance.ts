/**
 * Performance optimization utilities for the application
 */

/**
 * Creates a debounced function that delays invoking the provided function
 * until after the specified wait time has elapsed since the last time it was invoked.
 *
 * @param func The function to debounce
 * @param wait The number of milliseconds to delay
 * @returns A debounced version of the function
 */
export function debounce<T extends (...args: any[]) => any>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null

  return (...args: Parameters<T>): void => {
    const later = () => {
      timeout = null
      func(...args)
    }

    if (timeout) {
      clearTimeout(timeout)
    }

    timeout = setTimeout(later, wait)
  }
}

/**
 * Creates a throttled function that only invokes the provided function
 * at most once per every specified wait milliseconds.
 *
 * @param func The function to throttle
 * @param wait The number of milliseconds to throttle invocations to
 * @returns A throttled version of the function
 */
export function throttle<T extends (...args: any[]) => any>(func: T, wait: number): (...args: Parameters<T>) => void {
  let lastCall = 0
  let timeout: NodeJS.Timeout | null = null

  return (...args: Parameters<T>): void => {
    const now = Date.now()
    const timeSinceLastCall = now - lastCall

    if (timeSinceLastCall >= wait) {
      lastCall = now
      func(...args)
    } else {
      if (timeout) {
        clearTimeout(timeout)
      }

      timeout = setTimeout(() => {
        lastCall = Date.now()
        func(...args)
      }, wait - timeSinceLastCall)
    }
  }
}

/**
 * Memoizes a function to cache its results based on the arguments provided.
 * This is useful for expensive calculations that are called with the same arguments.
 *
 * @param func The function to memoize
 * @returns A memoized version of the function
 */
export function memoize<T extends (...args: any[]) => any>(func: T): (...args: Parameters<T>) => ReturnType<T> {
  const cache = new Map<string, ReturnType<T>>()

  return (...args: Parameters<T>): ReturnType<T> => {
    const key = JSON.stringify(args)

    if (cache.has(key)) {
      return cache.get(key) as ReturnType<T>
    }

    const result = func(...args)
    cache.set(key, result)

    return result
  }
}

/**
 * Creates a function that will only execute once the browser is idle,
 * using requestIdleCallback with a fallback to setTimeout.
 *
 * @param func The function to execute during idle time
 * @param timeout Optional timeout in ms after which to execute the function anyway
 * @returns A function that schedules execution during idle time
 */
export function runWhenIdle<T extends (...args: any[]) => any>(
  func: T,
  timeout = 1000,
): (...args: Parameters<T>) => void {
  return (...args: Parameters<T>): void => {
    if (typeof window !== "undefined" && "requestIdleCallback" in window) {
      ;(window as any).requestIdleCallback(() => func(...args), { timeout })
    } else {
      setTimeout(() => func(...args), 1)
    }
  }
}

