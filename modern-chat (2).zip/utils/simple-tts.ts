/**
 * A simplified text-to-speech utility that works directly with the browser's speech synthesis
 */

// Simple function to speak text with minimal processing
export function speakText(text: string): Promise<void> {
  return new Promise((resolve, reject) => {
    // Check if speech synthesis is available
    if (typeof window === "undefined" || !window.speechSynthesis) {
      console.error("Speech synthesis not supported")
      reject(new Error("Speech synthesis not supported in this browser"))
      return
    }

    try {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel()

      // Create a simple utterance with the full text
      const utterance = new SpeechSynthesisUtterance(text)

      // Set language if available
      if (navigator.language) {
        utterance.lang = navigator.language
      }

      // Set a slightly slower rate for better comprehension
      utterance.rate = 0.9

      // Handle completion
      utterance.onend = () => {
        resolve()
      }

      // Handle errors
      utterance.onerror = (event) => {
        console.error("Speech synthesis error:", event)
        reject(new Error("Speech synthesis failed"))
      }

      // Set a timeout to resolve the promise if speech synthesis takes too long
      const timeoutId = setTimeout(() => {
        window.speechSynthesis.cancel()
        resolve() // Resolve anyway to prevent hanging
      }, 10000) // 10 second timeout

      // Clean up the timeout when speech ends
      utterance.onend = () => {
        clearTimeout(timeoutId)
        resolve()
      }

      // Speak the text
      window.speechSynthesis.speak(utterance)
    } catch (error) {
      console.error("Error in speech synthesis:", error)
      reject(error)
    }
  })
}

