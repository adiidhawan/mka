export function extractKeywords(text: string, maxKeywords = 3): string {
  // Convert to lowercase and remove punctuation
  const cleanedText = text.toLowerCase().replace(/[^\w\s]/g, "")

  // Split into words
  const words = cleanedText.split(/\s+/)

  // Remove common stop words (you can expand this list)
  const stopWords = new Set(["the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with", "by"])
  const filteredWords = words.filter((word) => !stopWords.has(word))

  // Sort words by length (assuming longer words are more important)
  const sortedWords = filteredWords.sort((a, b) => b.length - a.length)

  // Select top keywords
  const selectedKeywords = sortedWords.slice(0, maxKeywords)

  // Capitalize first letter of each keyword
  const capitalizedKeywords = selectedKeywords.map((word) => word.charAt(0).toUpperCase() + word.slice(1))

  // Join keywords into a chat name, limit to 10 characters, and add ellipsis
  let chatName = capitalizedKeywords.join(" ")
  if (chatName.length > 10) {
    chatName = chatName.slice(0, 10)
  }
  chatName = chatName.trim() + "..."

  return chatName
}

