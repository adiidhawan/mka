/**
 * A utility to safely use ResizeObserver without causing loop errors
 */

interface SafeResizeObserverOptions {
  onResize: (entry: ResizeObserverEntry) => void
  debounceTime?: number
}

export function createSafeResizeObserver({ onResize, debounceTime = 10 }: SafeResizeObserverOptions): {
  observe: (element: Element) => void
  disconnect: () => void
} {
  let timeout: NodeJS.Timeout | null = null
  let observer: ResizeObserver | null = null

  // Create a debounced resize handler to prevent loop errors
  const handleResize = (entries: ResizeObserverEntry[]) => {
    if (timeout) {
      clearTimeout(timeout)
    }

    timeout = setTimeout(() => {
      for (const entry of entries) {
        onResize(entry)
      }
    }, debounceTime)
  }

  // Create the observer with error handling
  try {
    observer = new ResizeObserver((entries) => {
      // Use requestAnimationFrame to avoid layout thrashing
      window.requestAnimationFrame(() => {
        handleResize(entries)
      })
    })
  } catch (error) {
    console.error("ResizeObserver not supported:", error)
  }

  return {
    observe: (element: Element) => {
      if (observer) {
        try {
          observer.observe(element)
        } catch (error) {
          console.error("Failed to observe element:", error)
        }
      }
    },
    disconnect: () => {
      if (observer) {
        observer.disconnect()
      }
      if (timeout) {
        clearTimeout(timeout)
      }
    },
  }
}

