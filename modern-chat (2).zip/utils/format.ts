/**
 * Utility functions for formatting data
 */

/**
 * Extracts keywords from text to create a chat name
 */
export function extractKeywords(text: string, maxKeywords = 3): string {
  // Convert to lowercase and remove punctuation
  const cleanedText = text.toLowerCase().replace(/[^\w\s]/g, "")

  // Split into words
  const words = cleanedText.split(/\s+/)

  // Remove common stop words
  const stopWords = new Set([
    "the",
    "a",
    "an",
    "and",
    "or",
    "but",
    "in",
    "on",
    "at",
    "to",
    "for",
    "of",
    "with",
    "by",
    "is",
    "are",
  ])
  const filteredWords = words.filter((word) => !stopWords.has(word))

  // Sort words by length (assuming longer words are more important)
  const sortedWords = filteredWords.sort((a, b) => b.length - a.length)

  // Select top keywords
  const selectedKeywords = sortedWords.slice(0, maxKeywords)

  // Capitalize first letter of each keyword
  const capitalizedKeywords = selectedKeywords.map((word) => word.charAt(0).toUpperCase() + word.slice(1))

  // Join keywords into a chat name, limit to 20 characters, and add ellipsis if needed
  let chatName = capitalizedKeywords.join(" ")
  if (chatName.length > 20) {
    chatName = chatName.slice(0, 20) + "..."
  } else if (chatName.length === 0) {
    chatName = "New Chat"
  }

  return chatName.trim()
}

/**
 * Returns a greeting based on the time of day
 */
export function getGreeting(userName = "User"): string {
  const hour = new Date().getHours()
  let timeOfDay: string

  if (hour >= 5 && hour < 12) {
    timeOfDay = "morning"
  } else if (hour >= 12 && hour < 17) {
    timeOfDay = "afternoon"
  } else if (hour >= 17 && hour < 22) {
    timeOfDay = "evening"
  } else {
    timeOfDay = "night"
  }

  return `Good ${timeOfDay} ${userName}, greetings from Maintenance Mitra`
}

/**
 * Formats a timestamp relative to current time
 */
export function formatRelativeTime(date: Date): string {
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(minutes / 60)
  const days = Math.floor(hours / 24)
  const months = Math.floor(days / 30)

  if (months > 0) return `${months} month${months === 1 ? "" : "s"} ago`
  if (days > 0) return `${days} day${days === 1 ? "" : "s"} ago`
  if (hours > 0) return `${hours} hour${hours === 1 ? "" : "s"} ago`
  if (minutes > 0) return `${minutes} minute${minutes === 1 ? "" : "s"} ago`
  return "Just now"
}

