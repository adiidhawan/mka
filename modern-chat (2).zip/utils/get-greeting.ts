export function getGreeting(userName = "User"): string {
  const hour = new Date().getHours()
  let timeOfDay: string

  if (hour >= 5 && hour < 12) {
    timeOfDay = "morning"
  } else if (hour >= 12 && hour < 17) {
    timeOfDay = "afternoon"
  } else if (hour >= 17 && hour < 22) {
    timeOfDay = "evening"
  } else {
    timeOfDay = "night"
  }

  return `Good ${timeOfDay} ${userName}, greetings from Maintenance Mitra`
}

