/**
 * API client for backend services
 */
import axios from "axios"

const BASE_URL = "https://tml-az-dev-pvevops-mka-be-app.azurewebsites.net"

// Update the axios instance configuration to increase the timeout
const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000, // Increase timeout to 30 seconds
})

// Improve the fallbackTTS function to be more robust
export const fallbackTTS = (text: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      console.error("Browser doesn't support speech synthesis")
      reject(new Error("Browser doesn't support speech synthesis"))
      return
    }

    try {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel()

      // Break text into smaller chunks if it's too long
      const maxLength = 150
      const textChunks = []

      if (text.length > maxLength) {
        // Split by sentences or periods to create natural breaks
        const sentences = text.split(/(?<=[.!?])\s+/)
        let currentChunk = ""

        for (const sentence of sentences) {
          if (currentChunk.length + sentence.length <= maxLength) {
            currentChunk += sentence + " "
          } else {
            if (currentChunk) {
              textChunks.push(currentChunk.trim())
            }
            currentChunk = sentence + " "
          }
        }

        if (currentChunk) {
          textChunks.push(currentChunk.trim())
        }
      } else {
        textChunks.push(text)
      }

      let chunkIndex = 0

      const speakNextChunk = () => {
        if (chunkIndex >= textChunks.length) {
          resolve()
          return
        }

        const utterance = new SpeechSynthesisUtterance(textChunks[chunkIndex])

        // Set language if available
        if (navigator.language) {
          utterance.lang = navigator.language
        }

        // Adjust rate slightly for more natural speech
        utterance.rate = 0.9

        utterance.onend = () => {
          chunkIndex++
          speakNextChunk()
        }

        utterance.onerror = (event) => {
          console.error("Speech synthesis error:", event)
          // Continue with next chunk even if there's an error
          chunkIndex++
          speakNextChunk()
        }

        window.speechSynthesis.speak(utterance)
      }

      speakNextChunk()
    } catch (error) {
      console.error("Error in fallback TTS:", error)
      reject(error)
    }
  })
}

// Add a retry mechanism for the query function
export const apiService = {
  // Test connection to API
  testConnection: () => api.get("/"),

  // Send query to backend with retry mechanism
  query: async (query: string, machineName: string, retries = 2) => {
    let lastError

    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        return await api.post(
          "/query",
          { query, machine_name: machineName },
          {
            timeout: 60000, // 60 seconds timeout for query requests specifically
          },
        )
      } catch (error) {
        lastError = error
        console.warn(`API query attempt ${attempt + 1}/${retries + 1} failed:`, error)

        // If it's not the last attempt, wait before retrying
        if (attempt < retries) {
          // Exponential backoff: wait longer with each retry
          const delay = 1000 * Math.pow(2, attempt) // 1s, 2s, 4s, etc.
          await new Promise((resolve) => setTimeout(resolve, delay))
        }
      }
    }

    // If we've exhausted all retries, throw the last error
    throw lastError
  },

  // Keep the rest of the methods as they are
  speechToText: (audioBlob: Blob) => {
    const formData = new FormData()
    formData.append("file", audioBlob, "audio.webm")
    return api.post("/speech_to_text/", formData, {
      headers: { "Content-Type": "multipart/form-data" },
      timeout: 30000, // 30 seconds for speech to text
    })
  },

  translateResponse: (response: string, language: string) =>
    api.post(
      "/translated_response/",
      { response, language },
      {
        timeout: 30000, // 30 seconds for translation
      },
    ),

  // Improved textToSpeech function with better error handling and fallback
  textToSpeech: async (response: string, language: string) => {
    // Skip the API call entirely and use the browser's built-in TTS
    console.log("Bypassing TTS API due to persistent 500 errors, using browser TTS directly")
    return { success: true, fallback: true }
  },

  // Submit feedback
  submitFeedback: (runId: string, score: number, value: string, comment: string) =>
    api.post(
      "/feedback",
      { run_id: runId, score, value, comment },
      {
        timeout: 15000, // 15 seconds for feedback
      },
    ),
}

export default api

