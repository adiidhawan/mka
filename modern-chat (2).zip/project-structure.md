# Refactored Project Structure

## Core Components
- app/
  - layout.tsx (Root layout)
  - page.tsx (Home page with redirect)
  - chat/
    - page.tsx (Main chat interface)
  - login/
    - page.tsx (Login page)
  - api/
    - chat/
      - route.ts (Chat API endpoint)

## Components
- components/
  - ui/ (shadcn components)
  - chat/
    - chat-interface.tsx (Main chat component)
    - message-list.tsx (Messages display)
    - input-area.tsx (Chat input)
    - reaction-buttons.tsx (Message reactions)
  - layout/
    - header.tsx (App header)
    - sidebar.tsx (Chat sidebar)
  - shared/
    - animated-background.tsx
    - theme-toggle.tsx
    - error-boundary.tsx

## Hooks
- hooks/
  - use-chat.ts (Chat state management)
  - use-audio-recording.ts (Audio recording functionality)
  - use-window-size.ts (Responsive design)
  - use-debounced-effect.ts (Performance optimization)

## Utils
- utils/
  - api.ts (API client)
  - format.ts (Formatting utilities)
  - performance.ts (Performance utilities)
  - safe-resize-observer.ts (ResizeObserver utility)

## Contexts
- contexts/
  - theme-context.tsx (Theme management)
  - chat-sessions-context.tsx (Chat sessions management)

## Types
- types/
  - chat.ts (Chat-related types)
  - index.ts (Common types)

