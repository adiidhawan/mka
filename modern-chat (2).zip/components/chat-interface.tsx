"use client"

import { useState, useRef, useEffect, useMemo, useCallback } from "react"
import { FeedbackDialog } from "@/components/feedback-dialog"
import { useTheme } from "@/contexts/ThemeContext"
import { ErrorBoundary } from "@/components/error-boundary"
import { MessageList } from "@/components/message-list"
import { InputArea } from "@/components/input-area"
import { ThemeToggle } from "@/components/theme-toggle"
import { useChat } from "@/hooks/use-chat"
import { useAudioRecording } from "@/hooks/use-audio-recording"
import { apiService, fallbackTTS } from "@/lib/api"
import { toast } from "@/components/ui/use-toast"
import { getGreeting } from "@/utils/get-greeting"
import { ChatHeader } from "@/components/chat-header"
import { cn } from "@/lib/utils"
import type { Message } from "@/types"

interface ChatInterfaceProps {
  isSidebarPinned: boolean
  selectedChat: any
  onNewMessage: (message: string) => void
  initialState?: boolean
  toggleStarChat: (chatId: string) => void
  createNewChat: () => void
  updateChatName: (chatId: string, newName: string) => void
  setIsInitialState: (value: boolean) => void
  machines: Array<{
    id: string
    name: string
    icon: string
  }>
  updateChatMachine: (chatId: string, machine: { id: string; name: string; icon: string } | null) => void
}

export default function ChatInterface({
  isSidebarPinned,
  selectedChat,
  onNewMessage,
  initialState = true,
  toggleStarChat,
  createNewChat,
  updateChatName,
  setIsInitialState,
  machines,
  updateChatMachine,
}: ChatInterfaceProps) {
  const { theme } = useTheme()
  const {
    messages,
    handleSubmit: originalHandleSubmit,
    handleReactionClick,
    handleFeedbackSubmit,
    handleFeedbackCancel,
    activeReactions,
    pendingReactions,
    temporaryActions,
    activeFeedback,
    isLoading,
    error,
    setMessages,
    setIsLoading,
    setError,
  } = useChat()

  const { isRecording, recordingTime, startRecording, stopRecording, cancelRecording, handleRecordingSubmit } =
    useAudioRecording(setMessages)

  const [selectedLanguage, setSelectedLanguage] = useState("en")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [isInitialState, _setIsInitialState] = useState(initialState)
  const [greeting, setGreeting] = useState("")

  // Sync local state with prop
  useEffect(() => {
    _setIsInitialState(initialState)
  }, [initialState])

  // Scroll to bottom when messages change
  useEffect(() => {
    // Use requestAnimationFrame for smoother scrolling
    const scrollToBottom = () => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
      }
    }

    // Delay scrolling slightly to ensure DOM has updated
    const timeoutId = setTimeout(() => {
      requestAnimationFrame(scrollToBottom)
    }, 100)

    return () => clearTimeout(timeoutId)
  }, [messages])

  // Update greeting periodically
  useEffect(() => {
    setGreeting(getGreeting())
    const interval = setInterval(() => setGreeting(getGreeting()), 60000)
    return () => clearInterval(interval)
  }, [])

  // Update the handleSubmit function to include machine information
  const handleSubmit = useCallback(
    async (message: string) => {
      if (!message.trim()) return

      // Update both local and parent state
      _setIsInitialState(false)
      setIsInitialState(false)
      setIsLoading(true)

      try {
        // Add user message to local state for immediate feedback
        const newUserMessage: Message = {
          id: Date.now().toString(),
          role: "user",
          content: message.trim(),
          machine: selectedChat?.machines?.[0] || null,
        }

        setMessages((prev) => [...prev, newUserMessage])

        // Send message to parent for processing
        onNewMessage(message)
      } catch (error) {
        console.error("Error submitting message:", error)
        setError("Failed to send message. Please try again.")
      } finally {
        setIsLoading(false)
      }
    },
    [onNewMessage, setIsInitialState, selectedChat?.machines, setMessages, setIsLoading, setError],
  )

  const handleLanguageChange = useCallback(
    async (language: string) => {
      setSelectedLanguage(language)
      if (messages.length > 0 && language !== "en") {
        const lastMessage = messages[messages.length - 1]
        try {
          const translatedResponse = await apiService.translateResponse(lastMessage.content, language)
          setMessages((prevMessages) => {
            const updatedMessages = [...prevMessages]
            updatedMessages[updatedMessages.length - 1] = {
              ...updatedMessages[updatedMessages.length - 1],
              content: translatedResponse.data,
            }
            return updatedMessages
          })
        } catch (error) {
          console.error("Error translating response:", error)
          toast({
            title: "Translation Error",
            description: "Failed to translate the message. Please try again.",
            variant: "destructive",
          })
        }
      }
    },
    [messages, setMessages],
  )

  const playTextToSpeech = useCallback(
    async (text: string) => {
      if (typeof text !== "string") {
        console.error("Invalid text for text-to-speech:", text)
        toast({
          title: "Text-to-Speech Error",
          description: "Invalid text format. Please try again.",
          variant: "destructive",
        })
        return
      }

      try {
        const result = await apiService.textToSpeech(text, selectedLanguage)
        if (result.success) {
          const audio = new Audio(result.data)
          audio.onerror = (e) => {
            console.error("Audio playback error:", e)
            toast({
              title: "Playback Error",
              description: "Failed to play the audio. Please try again.",
              variant: "destructive",
            })
          }
          await audio.play()
        } else if (result.fallback) {
          toast({
            title: "Using Fallback TTS",
            description: "The primary TTS service is unavailable. Using browser's built-in TTS.",
            variant: "warning",
          })
          await fallbackTTS(text)
        } else {
          throw new Error("Text-to-speech conversion failed")
        }
      } catch (error) {
        console.error("Error playing text-to-speech:", error)
        toast({
          title: "Text-to-Speech Error",
          description: "Failed to convert text to speech. Please try again later.",
          variant: "destructive",
        })
      }
    },
    [selectedLanguage],
  )

  const handleNewChatClick = useCallback(() => {
    createNewChat()
    _setIsInitialState(true)
    setIsInitialState(true)
  }, [createNewChat, setIsInitialState])

  const handleMachineChange = useCallback(
    (machine: { id: string; name: string; icon: string } | null) => {
      if (selectedChat) {
        updateChatMachine(selectedChat.id, machine)
      }
    },
    [selectedChat, updateChatMachine],
  )

  // Memoize components to prevent unnecessary re-renders
  const memoizedMessageList = useMemo(
    () => (
      <MessageList
        messages={selectedChat?.messages || messages}
        activeReactions={activeReactions}
        pendingReactions={pendingReactions}
        temporaryActions={temporaryActions}
        handleReactionClick={handleReactionClick}
        theme={theme}
        playTextToSpeech={playTextToSpeech}
        isLoading={isLoading}
        selectedMachine={selectedChat?.machines?.[0] || null}
      />
    ),
    [
      selectedChat?.messages,
      messages,
      activeReactions,
      pendingReactions,
      temporaryActions,
      handleReactionClick,
      theme,
      playTextToSpeech,
      isLoading,
      selectedChat?.machines,
    ],
  )

  const memoizedInputArea = useMemo(
    () => (
      <InputArea
        isSidebarPinned={isSidebarPinned}
        selectedMachines={selectedChat?.machines || []}
        isRecording={isRecording}
        recordingTime={recordingTime}
        handleSubmit={handleSubmit}
        handleRecordingSubmit={handleRecordingSubmit}
        startRecording={startRecording}
        stopRecording={stopRecording}
        cancelRecording={cancelRecording}
        isInitialState={isInitialState}
        setIsInitialState={(value) => {
          _setIsInitialState(value)
          setIsInitialState(value)
        }}
        greeting={greeting}
      />
    ),
    [
      isSidebarPinned,
      selectedChat?.machines,
      isRecording,
      recordingTime,
      handleSubmit,
      handleRecordingSubmit,
      startRecording,
      stopRecording,
      cancelRecording,
      isInitialState,
      setIsInitialState,
      greeting,
    ],
  )

  const memoizedChatHeader = useMemo(
    () => (
      <ChatHeader
        className={isSidebarPinned ? "left-80" : "left-0"}
        selectedMachines={selectedChat?.machines || []}
        onMachineChange={handleMachineChange}
        chat={selectedChat}
        onToggleStar={toggleStarChat}
        onNewChat={handleNewChatClick}
        onRename={updateChatName}
        isInitialState={isInitialState}
        isActive={!isInitialState}
        machines={machines}
      />
    ),
    [
      isSidebarPinned,
      selectedChat,
      handleMachineChange,
      toggleStarChat,
      handleNewChatClick,
      updateChatName,
      isInitialState,
      machines,
    ],
  )

  return (
    <ErrorBoundary>
      <div className="relative flex h-[calc(100vh-43px)] flex-col">
        {error && (
          <div className="absolute top-0 left-0 right-0 bg-red-500 text-white p-2 text-center z-50">{error}</div>
        )}

        {memoizedChatHeader}

        {isInitialState ? (
          <div className="flex items-center justify-center h-full">
            <div className="w-full max-w-3xl px-4">
              <h1 className="text-4xl font-semibold text-center mb-8 relative z-10">
                <span
                  className={cn(
                    "bg-clip-text text-transparent animate-gradient-x-enhanced outer-glow",
                    theme === "light"
                      ? "bg-gradient-to-r from-purple-400 via-black to-purple-400"
                      : "bg-gradient-to-r from-purple-400 via-white to-purple-400",
                  )}
                >
                  {greeting}
                </span>
              </h1>
              {memoizedInputArea}
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto pt-14 pb-[120px] custom-scrollbar">
              <div className={cn("mx-auto max-w-3xl px-4 pb-36", isSidebarPinned ? "ml-2" : "")}>
                {memoizedMessageList}
                <div ref={messagesEndRef} />
              </div>
            </div>
            {memoizedInputArea}
          </>
        )}

        <ThemeToggle />

        {activeFeedback && (
          <FeedbackDialog type={activeFeedback.type} onClose={handleFeedbackCancel} onSubmit={handleFeedbackSubmit} />
        )}
      </div>
    </ErrorBoundary>
  )
}

