"use client"

import type React from "react"
import { Star, PlusCircle, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useTheme } from "@/contexts/ThemeContext"
import type { ChatItem, Machine } from "@/types/chat"

// Custom chat bubble icon
function ChatBubbleIcon({ className }: { className?: string }) {
  const { theme } = useTheme()
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 13.9021 3.5901 15.6665 4.59721 17.1199C4.70168 17.2707 4.7226 17.4653 4.64529 17.6317L3.42747 20.2519C3.23699 20.5853 3.47768 21 3.86159 21H12Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

interface ChatHeaderProps {
  className?: string
  chat?: ChatItem | null
  isSidebarPinned?: boolean
  selectedMachines: Machine[] | []
  onMachineChange: (machine: Machine | null) => void
  onToggleStar?: (chatId: string) => void
  onNewChat: () => void
  onRename: (chatId: string, newTitle: string) => void
  isInitialState: boolean
  isActive?: boolean
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  className,
  chat,
  isSidebarPinned = false,
  selectedMachines,
  onMachineChange,
  onToggleStar,
  onNewChat,
  onRename,
  isInitialState,
  isActive,
}) => {
  const { theme } = useTheme()

  const handleNewChatClick = () => {
    onNewChat()
  }

  // Check if a machine is already selected
  const isMachineSelected = (machineId: string) => {
    return selectedMachines.some((m) => m.id === machineId)
  }

  // Define machines
  const MACHINES = [
    { id: "Conveyor", name: "Conveyor" },
    { id: "ED Oven", name: "ED Oven" },
    { id: "Paint Robot", name: "Paint Robot" },
    { id: "Sealer Oven", name: "Sealer Oven" },
    { id: "Topcoat Oven", name: "Topcoat Oven" },
    { id: "Wax Robot", name: "Wax Robot" },
  ]

  return (
    <div
      className={cn(
        "fixed top-[42px] left-0 right-0 z-10 flex h-14 items-center justify-between px-4 transition-all duration-500 ease-in-out",
        "bg-white dark:bg-[#141619]/60 backdrop-blur-md",
        className,
        isSidebarPinned ? "ml-16" : "",
      )}
    >
      <div className="flex items-center">
        {!isInitialState && (
          <div className="flex items-center gap-3 px-2 py-2 rounded-xl">
            <div className="flex h-8 w-8 items-center justify-center">
              <ChatBubbleIcon
                className={cn(
                  theme === "light" ? "text-black" : "text-white filter drop-shadow-[0_0_3px_rgba(255,255,255,0.5)]",
                )}
              />
            </div>
            <h2
              className={cn(
                "text-sm font-medium mr-2",
                theme === "dark" ? "text-white filter drop-shadow-[0_0_3px_rgba(255,255,255,0.5)]" : "text-black",
              )}
            >
              {chat?.title || "New Maintenance Mitra Chat"}
            </h2>
          </div>
        )}
      </div>
      <div className="flex items-center gap-3">
        {!isInitialState && (
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-10 w-10 rounded-full transition-all duration-300",
              chat?.isStarred
                ? "bg-yellow-500 text-white shadow-lg shadow-yellow-500/50"
                : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600",
            )}
            onClick={() => chat && onToggleStar?.(chat.id)}
          >
            <Star className={cn("h-5 w-5", chat?.isStarred && "fill-current")} />
            <span className="sr-only">{chat?.isStarred ? "Unstar chat" : "Star chat"}</span>
          </Button>
        )}

        {!isInitialState && (
          <Button
            variant="ghost"
            className={cn(
              "h-10 px-2 rounded-full flex items-center gap-1 w-[84px]",
              theme === "light" ? "bg-black hover:bg-black/90 text-white" : "bg-white hover:bg-white/90 text-black",
            )}
            onClick={handleNewChatClick}
          >
            <span className="text-[10px] font-medium whitespace-nowrap">New chat</span>
            <PlusCircle className="h-4 w-4 flex-shrink-0" />
          </Button>
        )}

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className={cn(
                "h-10 px-4 rounded-lg text-white hover:text-white flex items-center gap-2.5 transition-all duration-300",
                selectedMachines.length > 0
                  ? "bg-[#281E5D] shadow-[0_0_20px_rgba(100,149,237,0.7)]"
                  : "bg-[#281E5D] hover:bg-[#332973] shadow-[0_0_15px_rgba(100,149,237,0.4)]",
              )}
            >
              <span className="text-sm font-medium min-w-[120px] text-left">
                {selectedMachines.length > 0 ? selectedMachines[0].name : "Select Machine"}
              </span>
              <ChevronDown className="h-4 w-4 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="end"
            className="w-[300px] bg-white dark:bg-[#1A1D21]/95 border-gray-200 dark:border-gray-800 backdrop-blur-sm p-2"
          >
            {selectedMachines.length > 0 && (
              <DropdownMenuItem
                onClick={() => {
                  onMachineChange(null)
                }}
                className="text-gray-700 dark:text-gray-300 focus:bg-gray-100 dark:focus:bg-[#281E5D] focus:text-gray-900 dark:focus:text-white mb-2"
              >
                Clear selected machines
              </DropdownMenuItem>
            )}
            <div className="grid grid-cols-1 gap-2">
              {MACHINES.map((machine) => (
                <DropdownMenuItem
                  key={machine.id}
                  onClick={() => {
                    onMachineChange(machine)
                  }}
                  className={cn(
                    "flex items-center p-3 cursor-pointer rounded-lg transition-all",
                    isMachineSelected(machine.id)
                      ? "bg-[#281E5D] text-white"
                      : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#281E5D]/50",
                  )}
                >
                  <div className="font-medium">{machine.name}</div>
                </DropdownMenuItem>
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}

