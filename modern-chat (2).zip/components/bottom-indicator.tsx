"use client"

import React from "react"
import { PanelLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useTheme } from "@/contexts/ThemeContext"

interface BottomIndicatorProps {
  isVisible: boolean
  isSidebarOpen: boolean
  onOpenSidebar: () => void
}

export const BottomIndicator: React.FC<BottomIndicatorProps> = React.memo(
  ({ isVisible, isSidebarOpen, onOpenSidebar }) => {
    const { theme } = useTheme()

    if (isSidebarOpen) {
      return null
    }

    return (
      <div className="fixed left-4 bottom-[2vh] z-40 transition-opacity duration-400 ease-in-out">
        <Button
          onClick={onOpenSidebar}
          className={cn(
            "flex flex-col items-center gap-1 p-3 rounded-lg",
            theme === "light"
              ? "bg-white/80 text-black hover:bg-white/90"
              : "bg-[#1A1D21]/90 text-gray-400 hover:bg-[#1A1D21]",
          )}
        >
          <PanelLeft className="w-6 h-6 mb-1" />
          <div className="text-[10px] font-medium flex flex-col items-center leading-[1.1]">
            <span>OPEN</span>
            <span>SIDEBAR</span>
          </div>
        </Button>
      </div>
    )
  },
)

BottomIndicator.displayName = "BottomIndicator"

