"use client"

import { useTheme } from "@/contexts/ThemeContext"

// Function to generate floating paths with proper visibility
function FloatingPaths({ theme }: { theme: string }) {
  const paths = Array.from({ length: 36 }, (_, i) => ({
    id: i,
    d: `M-${380 - i * 5} -${189 + i * 6}C-${380 - i * 5} -${189 + i * 6} -${312 - i * 5} ${216 - i * 6} ${
      152 - i * 5
    } ${343 - i * 6}C${616 - i * 5} ${470 - i * 6} ${684 - i * 5} ${875 - i * 6} ${684 - i * 5} ${875 - i * 6}`,
    width: theme === "dark" ? 0.8 + i * 0.04 : 0.5 + i * 0.03, // Thicker lines for dark mode
  }))

  // Determine color and opacity based on theme
  const getPathColor = (index: number) => {
    if (theme === "light") {
      const baseOpacity = 0.05
      const opacityMultiplier = 0.005
      const pathOpacity = baseOpacity + index * opacityMultiplier
      return `rgba(59, 130, 246, ${pathOpacity})` // Blue for light mode
    } else {
      const baseOpacity = 0.2 // Increased base opacity for dark mode
      const opacityMultiplier = 0.015 // Increased multiplier for dark mode
      const pathOpacity = baseOpacity + index * opacityMultiplier
      return `rgba(255, 255, 255, ${pathOpacity})` // White for dark mode
    }
  }

  return (
    <div className="absolute inset-0 pointer-events-none">
      <svg className="w-full h-full" viewBox="0 0 696 316" fill="none" preserveAspectRatio="xMidYMid slice">
        <title>Background Paths</title>
        {paths.map((path) => (
          <path
            key={path.id}
            d={path.d}
            stroke={getPathColor(path.id)}
            strokeWidth={path.width}
            className="transition-opacity duration-300"
          />
        ))}
      </svg>
    </div>
  )
}

export function StaticBackground() {
  const { theme } = useTheme()

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Background color */}
      <div
        className={`absolute inset-0 ${
          theme === "light" ? "bg-gradient-to-br from-blue-50/40 via-white/60 to-blue-50/40" : "bg-[#141619]" // Dark grey background
        }`}
      />

      {/* Background patterns */}
      <div className="absolute inset-0 overflow-hidden">
        <FloatingPaths theme={theme} />
      </div>
    </div>
  )
}

