"use client"

import React, { useState } from "react"
import { Moon, Sun, BookOpen, LogOut, X, Plus } from "lucide-react"
import { useTheme } from "@/contexts/ThemeContext"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
// Import the UserGuideDialog component
import { UserGuideDialog } from "@/components/user-guide-dialog"

export const ThemeToggle: React.FC = React.memo(() => {
  const { theme, toggleTheme } = useTheme()
  // Change the mode state to only allow "light" or "dark"
  const [mode, setMode] = useState<"light" | "dark">(() => {
    if (typeof window !== "undefined") {
      const savedMode = localStorage.getItem("theme-mode") as "light" | "dark"
      return savedMode || "dark" // Default to dark if no saved theme
    }
    return "dark" // Default for server-side rendering
  })
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isHovered, setIsHovered] = useState(false)
  const [showSignOutDialog, setShowSignOutDialog] = useState(false)
  // Add a state for showing the user guide
  const [showUserGuide, setShowUserGuide] = useState(false)
  const router = useRouter()

  // Update the menuItems array to include the action for user guide
  const menuItems = [
    { icon: BookOpen, text: "User Guide", color: "text-blue-500", action: "userguide" },
    { icon: LogOut, text: "Sign out", color: "text-red-500", action: "signout" },
  ]

  // Update the cycleMode function to toggle between light and dark only
  const cycleMode = () => {
    setMode((prevMode) => (prevMode === "light" ? "dark" : "light"))
    toggleTheme()
  }

  // Update the handleItemClick function to handle the user guide action
  const handleItemClick = (item: any) => {
    if (item.action === "signout") {
      setShowSignOutDialog(true)
    } else if (item.action === "userguide") {
      setShowUserGuide(true)
    } else if (item.onClick) {
      item.onClick()
    }
    setIsMenuOpen(false)
  }

  return (
    <div className="fixed bottom-6 right-4 z-50 flex flex-col items-end">
      {/* Animated Menu - Outside the main card */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="mb-4 flex flex-col items-end space-y-3"
          >
            {menuItems.map((item, index) => (
              <motion.div
                key={index}
                className={cn(
                  "flex items-center justify-end gap-2 rounded-lg px-4 py-2 shadow-lg cursor-pointer w-48",
                  theme === "light" ? "bg-white" : "bg-[#1A1D21]",
                  "hover:bg-opacity-90",
                )}
                initial={{ x: 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 50, opacity: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleItemClick(item)}
              >
                <span
                  className={cn(
                    "text-sm font-medium flex-1 truncate",
                    theme === "light" ? "text-gray-800" : "text-gray-200",
                  )}
                >
                  {item.text}
                </span>
                <div className={cn("flex h-8 w-8 items-center justify-center rounded-full flex-shrink-0", item.color)}>
                  <item.icon size={18} />
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main card with Avatar and Theme Toggle */}
      <div
        className={cn(
          "flex flex-col items-center gap-4 p-4 rounded-xl backdrop-blur-sm shadow-lg transition-colors",
          theme === "light" ? "bg-white/80 hover:bg-white/90" : "bg-[#1a2942]/80 hover:bg-[#1a2942]/90",
        )}
      >
        {/* Avatar */}
        <div
          className="cursor-pointer"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {isMenuOpen ? (
            <div className="h-12 w-12 rounded-full bg-red-500 flex items-center justify-center">
              <X className="w-6 h-6 text-white" />
            </div>
          ) : (
            <Avatar className={cn("h-12 w-12", theme === "light" ? "bg-white" : "bg-[#1A1D21]")}>
              <AvatarFallback className={cn("text-white transition-opacity duration-300", isHovered && "opacity-0")}>
                A
              </AvatarFallback>
              {isHovered && (
                <div className="absolute inset-0 flex items-center justify-center rounded-full bg-blue-500/70">
                  <Plus className="w-6 h-6 text-white" />
                </div>
              )}
            </Avatar>
          )}
        </div>

        {/* Theme Toggle */}
        <div className="flex flex-col items-center">
          <div
            className={cn(
              "w-14 h-8 rounded-full px-1 transition-all duration-300 ease-in-out cursor-pointer relative flex items-center",
              theme === "light" ? "bg-white border border-gray-200" : "bg-gray-800 border border-gray-700",
            )}
            onClick={cycleMode}
          >
            <div
              className={cn(
                "absolute w-6 h-6 rounded-full transition-all duration-300 ease-in-out flex items-center justify-center",
                theme === "dark"
                  ? "translate-x-6 bg-gray-700 text-gray-300"
                  : "translate-x-0 bg-gray-100 text-yellow-500",
              )}
            >
              {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </div>
          </div>
          <span className="text-xs font-medium text-gray-400 mt-2">
            {theme === "dark" ? "Dark mode" : "Light mode"}
          </span>
        </div>
      </div>
      {showSignOutDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-lg px-4">
            <div
              className={cn(
                "relative rounded-[20px] p-6 backdrop-blur-sm border shadow-lg",
                theme === "light"
                  ? "bg-[#E6F3FF] border-blue-200 text-gray-800"
                  : "bg-[#281E5D] border-gray-700/50 text-white",
              )}
            >
              <h3 className="mb-4 text-lg font-semibold">Sign Out</h3>

              <div className="mb-6">
                <p className="text-sm mb-3">Are you sure you want to sign out?</p>
              </div>

              <div className="flex justify-end gap-4">
                <Button
                  variant="ghost"
                  onClick={() => setShowSignOutDialog(false)}
                  className={cn(
                    "px-6",
                    theme === "light"
                      ? "text-gray-600 hover:text-gray-800 hover:bg-blue-100"
                      : "text-gray-400 hover:text-gray-300 hover:bg-[#281E5D]",
                  )}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowSignOutDialog(false)
                    router.push("/")
                  }}
                  className={cn(
                    "px-8 py-2.5 text-white",
                    theme === "light" ? "bg-blue-500 hover:bg-blue-600" : "bg-[#C66A3F] hover:bg-[#B55A2F]",
                  )}
                >
                  Yes, Sign Out
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      {showUserGuide && <UserGuideDialog onClose={() => setShowUserGuide(false)} />}
    </div>
  )
})

ThemeToggle.displayName = "ThemeToggle"

