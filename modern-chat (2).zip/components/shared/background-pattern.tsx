"use client"

import { useTheme } from "@/contexts/ThemeContext"
import { Factory, Truck, HardHat, BotIcon as Robot, Cog, Wrench, Gauge, Cpu, Package, Hammer } from "lucide-react"

const BACKGROUND_ICONS = [
  { icon: Factory },
  { icon: Truck },
  { icon: HardHat },
  { icon: Robot },
  { icon: Cog },
  { icon: Wrench },
  { icon: Gauge },
  { icon: Cpu },
  { icon: Package },
  { icon: Hammer },
]

export function BackgroundPattern() {
  const { theme } = useTheme()

  // Calculate the number of columns and rows needed to fill the screen
  const columns = 20
  const rows = 24 // Increased number of rows

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      <div
        className="absolute inset-0 grid gap-16 p-12 transform rotate-12"
        style={{
          gridTemplateColumns: `repeat(${columns}, 1fr)`,
          gridTemplateRows: `repeat(${rows}, 1fr)`,
          left: "-10%",
          width: "120%",
          top: "-15%", // Move the pattern up
          height: "115%", // Extend the height to cover the bottom
        }}
      >
        {Array(columns * rows)
          .fill(0)
          .map((_, index) => {
            const { icon: Icon } = BACKGROUND_ICONS[index % BACKGROUND_ICONS.length]
            const columnIndex = index % columns
            let bgColor = theme === "light" ? "text-gray-300" : "text-gray-700"
            let opacity = theme === "light" ? 0.2 : 0.1

            if (columnIndex % 4 === 0) {
              bgColor = theme === "light" ? "text-blue-400" : "text-blue-800"
              opacity = theme === "light" ? 0.3 : 0.15
            } else if (columnIndex % 4 === 1) {
              bgColor = theme === "light" ? "text-yellow-300" : "text-yellow-700"
              opacity = theme === "light" ? 0.25 : 0.12
            } else if (columnIndex % 4 === 2) {
              bgColor = theme === "light" ? "text-blue-300" : "text-blue-700"
              opacity = theme === "light" ? 0.25 : 0.12
            }

            return (
              <div
                key={index}
                className={`flex items-center justify-center ${bgColor}`}
                style={{
                  opacity,
                }}
              >
                <Icon size={32} />
              </div>
            )
          })}
      </div>
    </div>
  )
}

