"use client"

import { useState } from "react"
import { useTheme } from "@/contexts/ThemeContext"
import { cn } from "@/lib/utils"
import { ThemeToggle } from "@/components/theme-toggle"
import { ChatHeader } from "@/components/chat-header"
import { CenteredChatInput } from "@/components/centered-chat-input"

interface WelcomePageProps {
  onStartChat: () => void
  selectedMachine: string | null
  onMachineChange: (machine: string | null) => void
  onNewMessage: (message: string) => void
  userName?: string
}

export function WelcomePage({
  onStartChat,
  selectedMachine,
  onMachineChange,
  onNewMessage,
  userName = "User",
}: WelcomePageProps) {
  const { theme } = useTheme()
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (message: string) => {
    setIsLoading(true)
    try {
      await onNewMessage(message)
      onStartChat()
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white dark:bg-[#141619] text-black dark:text-white relative">
      <ChatHeader className="bg-transparent" selectedMachine={selectedMachine} onMachineChange={onMachineChange} />

      <CenteredChatInput
        onSubmit={handleSubmit}
        isLoading={isLoading}
        userName={userName}
        className={cn(
          "backdrop-blur-sm",
          theme === "light"
            ? "bg-[#E6F3FF]/80 shadow-[0_0_15px_rgba(100,149,237,0.2)]"
            : "bg-[#281E5D]/80 shadow-[0_0_20px_rgba(100,149,237,0.1)]",
        )}
      />

      <div className="fixed bottom-4 right-4">
        <ThemeToggle />
      </div>
    </div>
  )
}

