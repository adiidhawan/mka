"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Search, Star, Trash2, Edit, Moon, Sun, ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { useTheme } from "@/contexts/ThemeContext"
import type { ChatItem as ChatItemType } from "@/hooks/use-chat"
import { BottomIndicator } from "@/components/bottom-indicator"
import { ChatHistoryDialog } from "@/components/chat-history-dialog"

// Removed duplicate ChatItem component declaration

function CloseIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 4L4 12M4 4L12 12"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

interface ChatItemProps {
  chat: ChatItemType
  onSelect: (chat: ChatItemType) => void // Updated to accept ChatItemType
  onDelete: () => void
  onToggleStar: () => void
  onRename: (newTitle: string) => void
  machine?: {
    id: string
    name: string
    icon: string
  }
}

const ChatItem: React.FC<ChatItemProps> = ({ chat, onSelect, onDelete, onToggleStar, onRename }) => {
  const { theme } = useTheme()

  return (
    <div className="flex flex-col p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg cursor-pointer">
      <div className="flex items-center justify-between">
        <div
          className="flex-1 truncate"
          onClick={() => {
            // Create a new Date object with a timestamp slightly in the future to ensure it's the most recent
            const now = new Date()
            now.setMilliseconds(now.getMilliseconds() + 100)

            // Update the chat with the new date to make it the most recent chat
            const updatedChat = {
              ...chat,
              date: now,
            }

            // Select the updated chat
            onSelect(updatedChat)
          }}
        >
          {chat.title}
        </div>
        <div className="flex items-center space-x-3">
          <div className="group relative">
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleStar}
              className={cn(
                "h-7 w-7 rounded-full",
                chat.isStarred
                  ? "text-yellow-500 hover:text-yellow-400 hover:bg-yellow-500/10"
                  : "text-gray-400 hover:text-gray-300 hover:bg-gray-700/50",
              )}
            >
              <Star className="h-4 w-4" />
            </Button>
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              Star chat
            </span>
          </div>
          <div className="group relative">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onRename(chat.title)}
              className="h-7 w-7 rounded-full text-gray-400 hover:text-yellow-500 hover:bg-yellow-500/10 transition-colors duration-300"
            >
              <Edit className="h-4 w-4" />
            </Button>
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              Rename chat
            </span>
          </div>
          <div className="group relative">
            <Button
              variant="ghost"
              size="icon"
              onClick={onDelete}
              className="h-7 w-7 rounded-full text-gray-400 hover:text-red-500 hover:bg-red-500/10 transition-colors duration-300"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              Delete chat
            </span>
          </div>
        </div>
      </div>

      {/* Machine information */}
      {chat.machines && chat.machines.length > 0 && (
        <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
          <div className="flex items-center space-x-1.5">
            <span>
              {chat.machines
                .slice(0, 2)
                .map((machine) => machine.name)
                .join(", ")}
              {chat.machines.length > 2 &&
                `, ${chat.machines.length - 2} other${chat.machines.length - 2 > 1 ? "s" : ""}`}
            </span>
          </div>
        </div>
      )}
    </div>
  )
}

// Update the Sidebar component props to include onClose
interface SidebarProps {
  className?: string
  onClose: () => void
  onChatSelect: (chat: ChatItemType) => void
  chats: ChatItemType[]
  setChats: (chats: ChatItemType[]) => void
  onToggleStar: (chatId: string) => void
  onDeleteChat: (chatId: string) => void
  onRename: (chatId: string, newTitle: string) => void
  isOpen: boolean
}

export const Sidebar: React.FC<SidebarProps> = ({
  className,
  onClose,
  onChatSelect,
  chats,
  setChats,
  onToggleStar,
  onDeleteChat,
  onRename,
  isOpen,
}) => {
  const { theme } = useTheme()
  const [searchQuery, setSearchQuery] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)
  const [editedTitle, setEditedTitle] = useState("")
  const [dialogType, setDialogType] = useState<"rename" | "delete">("rename")
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false)
  const [validationError, setValidationError] = useState<string | null>(null)

  useEffect(() => {
    if (!dialogOpen) {
      setSelectedChatId(null)
      setEditedTitle("")
      setValidationError(null)
    }
  }, [dialogOpen])

  const filteredChats = chats.filter(
    (chat) => chat.messages.length > 1 && chat.title.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleDeleteClick = (chatId: string) => {
    setSelectedChatId(chatId)
    setDialogOpen(true)
    setDialogType("delete")
  }

  const handleDeleteConfirm = () => {
    if (selectedChatId) {
      onDeleteChat(selectedChatId)
    }
    setDialogOpen(false)
    setSelectedChatId(null)
  }

  const groupChatsByDate = (chats: ChatItemType[]) => {
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)
    const lastWeek = new Date(today)
    lastWeek.setDate(lastWeek.getDate() - 7)
    const lastMonth = new Date(today)
    lastMonth.setMonth(lastMonth.getMonth() - 1)
    const lastYear = new Date(today)
    lastYear.setFullYear(lastYear.getFullYear() - 1)

    return {
      today: chats.filter((chat) => chat.date.toDateString() === today.toDateString()),
      yesterday: chats.filter((chat) => chat.date.toDateString() === yesterday.toDateString()),
      "Past Week": chats.filter((chat) => chat.date > lastWeek && chat.date < yesterday),
      "Past Month": chats.filter((chat) => chat.date > lastMonth && chat.date <= lastWeek),
      "Past Year": chats.filter((chat) => chat.date > lastYear && chat.date <= lastMonth),
      older: chats.filter((chat) => chat.date <= lastYear),
    }
  }

  const recentChats = filteredChats.slice(0, 20)
  const groupedChats = groupChatsByDate(recentChats)

  return (
    <>
      {/* Sidebar */}
      <div
        data-sidebar
        className={cn(
          "fixed left-0 transition-all duration-500 ease-in-out z-40 flex flex-col",
          "top-[40px] bottom-0 w-[300px]",
          theme === "light" ? "bg-[#E6F3FF]" : "bg-[#141619]",
          isOpen ? "translate-x-0" : "-translate-x-full",
          className,
        )}
      >
        {/* Top section with Chat History text, close button, and search input */}
        <div className="flex flex-col p-3">
          <div className="flex justify-between items-center mb-3">
            {/* Chat History text */}
            <h2 className="text-sm font-semibold text-black dark:text-gray-200">Chat History</h2>

            {/* Close button */}
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 transition-colors hover:bg-transparent group relative text-[#8B0000]"
              onClick={onClose}
            >
              <CloseIcon />
              <span className="absolute top-1/2 right-full -translate-y-1/2 mr-2 bg-black/80 text-white text-xs px-2 py-1 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Close Sidebar
              </span>
            </Button>
          </div>

          {/* Search input */}
          <div className="relative">
            <Input
              type="text"
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-gray-800 border-gray-200 dark:border-[#1E3A8A] rounded-full pl-10 pr-4 py-2 text-sm text-gray-900 dark:text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
        </div>

        {/* Rest of the sidebar content remains the same */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-4">
          {/* Starred Section */}
          {filteredChats.some((chat) => chat.isStarred) && (
            <div className="mb-2">
              <h3 className="text-xs font-semibold text-black/70 dark:text-gray-400 mb-2 capitalize">Starred</h3>
              <div className="space-y-1">
                {filteredChats
                  .filter((chat) => chat.isStarred)
                  .map((chat) => (
                    <ChatItem
                      key={chat.id}
                      chat={chat}
                      onSelect={onChatSelect}
                      onDelete={() => handleDeleteClick(chat.id)}
                      onToggleStar={() => onToggleStar(chat.id)}
                      onRename={(currentTitle) => {
                        setSelectedChatId(chat.id)
                        setEditedTitle(currentTitle)
                        setDialogOpen(true)
                        setDialogType("rename")
                      }}
                    />
                  ))}
              </div>
            </div>
          )}

          {/* Time-based Sections */}
          {Object.entries(groupedChats).map(
            ([period, chats]) =>
              chats.length > 0 && (
                <div key={period} className="mb-2">
                  <h3 className="text-xs font-semibold text-black/70 dark:text-gray-400 mb-2 capitalize">{period}</h3>
                  <div className="space-y-1">
                    {chats.map((chat) => (
                      <ChatItem
                        key={chat.id}
                        chat={chat}
                        onSelect={onChatSelect}
                        onDelete={() => handleDeleteClick(chat.id)}
                        onToggleStar={() => onToggleStar(chat.id)}
                        onRename={(currentTitle) => {
                          setSelectedChatId(chat.id)
                          setEditedTitle(currentTitle)
                          setDialogOpen(true)
                          setDialogType("rename")
                        }}
                      />
                    ))}
                  </div>
                </div>
              ),
          )}
        </div>
        {/* View All Button */}
        <div className={cn("p-4 mt-auto border-t", theme === "light" ? "border-gray-200" : "border-gray-800")}>
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-between rounded-xl px-4 py-2.5 transition-opacity duration-200",
              theme === "light"
                ? "bg-black hover:bg-black hover:bg-opacity-90"
                : "bg-white hover:bg-white hover:bg-opacity-90",
            )}
            onClick={() => setIsHistoryDialogOpen(true)}
          >
            <span className={theme === "light" ? "text-white" : "text-black"}>View All Chats</span>
            <ArrowRight className={cn("h-4 w-4", theme === "light" ? "text-white" : "text-black")} />
          </Button>
        </div>

        {/* Chat History Dialog */}
        <ChatHistoryDialog
          isOpen={isHistoryDialogOpen}
          onClose={() => setIsHistoryDialogOpen(false)}
          chats={chats}
          onSelect={onChatSelect}
          onDelete={onDeleteChat}
          onToggleStar={onToggleStar}
          onRename={onRename}
        />
      </div>
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        {/* Dialog content remains the same */}
        <DialogContent
          className={cn(
            "sm:max-w-[425px]",
            theme === "light"
              ? "bg-[#E6F3FF] border-blue-200 text-gray-900"
              : "bg-[#281E5D] border-gray-700/50 text-white",
          )}
        >
          <DialogHeader>
            <DialogTitle className={cn("text-lg font-semibold", theme === "light" ? "text-gray-900" : "text-white")}>
              {dialogType === "rename" ? "Rename Chat" : "Delete Chat"}
            </DialogTitle>
          </DialogHeader>

          {dialogType === "rename" ? (
            <>
              <div className="py-4">
                <Input
                  value={editedTitle}
                  onChange={(e) => {
                    setEditedTitle(e.target.value)
                    // Clear validation error when user types
                    if (e.target.value.trim().length >= 3) {
                      setValidationError(null)
                    }
                  }}
                  placeholder="Enter new chat name"
                  className={cn(
                    theme === "light"
                      ? "bg-gray-100 border-gray-200 text-gray-900 placeholder-gray-500"
                      : "bg-[#1a2942] border-gray-700 text-white placeholder-gray-400",
                  )}
                  autoFocus
                />
                {validationError && (
                  <p className={cn("text-sm mt-2", theme === "light" ? "text-red-600" : "text-red-400")}>
                    {validationError}
                  </p>
                )}
              </div>
              <DialogFooter className="flex justify-end gap-3 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  className={cn(
                    "h-11 px-6 rounded-md",
                    theme === "light"
                      ? "text-gray-700 border-gray-300 hover:bg-gray-100"
                      : "text-gray-300 hover:text-white hover:bg-gray-800/50 border border-gray-600",
                  )}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    if (!editedTitle.trim()) {
                      setValidationError("Please enter a chat name")
                      return
                    }

                    if (editedTitle.trim().length < 3) {
                      setValidationError("Enter minimum 3 characters")
                      return
                    }

                    if (selectedChatId) {
                      onRename(selectedChatId, editedTitle.trim())
                      setDialogOpen(false)
                      setSelectedChatId(null)
                      setValidationError(null)
                    }
                  }}
                  disabled={!editedTitle.trim() || editedTitle.trim().length < 3}
                  className={cn(
                    "h-11 px-8 rounded-md text-white text-base font-medium",
                    theme === "light" ? "bg-blue-600 hover:bg-blue-700" : "bg-[#C66A3F] hover:bg-[#B55A2F]",
                    (!editedTitle.trim() || editedTitle.trim().length < 3) && "opacity-50 cursor-not-allowed",
                  )}
                >
                  Save
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <div className="py-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Are you sure you want to delete this chat? This action cannot be undone.
                </p>
              </div>
              <DialogFooter className="flex justify-end gap-3 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  className={cn(
                    "h-11 px-6 rounded-md",
                    theme === "light"
                      ? "text-gray-700 border-gray-300 hover:bg-gray-100"
                      : "text-gray-300 hover:text-white hover:bg-gray-800/50 border border-gray-600",
                  )}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleDeleteConfirm}
                  className="h-11 px-8 rounded-md bg-red-600 text-white hover:bg-red-700"
                >
                  Delete
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
      <BottomIndicator
        isVisible={true}
        isSidebarOpen={isOpen}
        onOpenSidebar={onClose} // We're reusing the onClose function to toggle the sidebar
      />
      <style jsx global>{`
        .custom-scrollbar {
          scrollbar-width: thin;
          scrollbar-color: rgba(255, 255, 255, 0.2) transparent;
        }

        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: rgba(255, 255, 255, 0.2);
          border-radius: 3px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background-color: rgba(255, 255, 255, 0.3);
        }
      `}</style>
    </>
  )
}

export const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme()

  return (
    <div className="fixed bottom-4 right-4 flex flex-col items-center gap-2">
      <div className="bg-white/80 dark:bg-[#1A1D21]/90 backdrop-blur-sm shadow-md rounded-lg p-2 flex items-center justify-center">
        <div
          className={cn(
            "w-14 h-8 rounded-full p-1 transition-colors duration-200 ease-in-out cursor-pointer",
            "bg-white/80 dark:bg-[#1A1D21]/90 border-2 border-gray-300 dark:border-gray-600",
            "shadow-[inset_0_1px_2px_rgba(0,0,0,0.1),_0_2px_4px_rgba(0,0,0,0.1)]",
            "hover:shadow-[inset_0_1px_2px_rgba(0,0,0,0.2),_0_3px_6px_rgba(0,0,0,0.2)]",
            "active:shadow-[inset_0_2px_4px_rgba(0,0,0,0.2)]",
          )}
          onClick={toggleTheme}
        >
          <div
            className={cn(
              "w-6 h-6 rounded-full transition-transform duration-200 ease-in-out flex items-center justify-center",
              theme === "dark" ? "bg-[#1A1D21] translate-x-6" : "bg-white",
              "shadow-[0_1px_3px_rgba(0,0,0,0.2)]",
            )}
          >
            {theme === "dark" ? (
              <Moon className="w-4 h-4 text-gray-300" />
            ) : (
              <Sun className="w-4 h-4 text-yellow-500" />
            )}
          </div>
        </div>
      </div>
      <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
        {theme === "dark" ? "Dark mode" : "Light mode"}
      </span>
    </div>
  )
}

