"use client"

import type React from "react"
import { useState } from "react"
import { useChat } from "@/hooks/useChat"

export const ChatInterface: React.FC = () => {
  const { currentSession, isLoading, error, sendMessage } = useChat()
  const [inputValue, setInputValue] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputValue.trim()) {
      sendMessage(inputValue.trim())
      setInputValue("")
    }
  }

  if (!currentSession) {
    return <div className="text-center p-4">No active chat session. Please create or select a session.</div>
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {currentSession.messages.map((message) => (
          <div
            key={message.id}
            className={`p-2 rounded-lg ${message.role === "user" ? "bg-blue-100 ml-auto" : "bg-gray-100"} max-w-[70%]`}
          >
            {message.content}
          </div>
        ))}
        {isLoading && <div className="text-center">Loading...</div>}
        {error && <div className="text-center text-red-500">{error}</div>}
      </div>
      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex space-x-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="flex-1 px-3 py-2 border rounded-lg"
            placeholder="Type your message..."
          />
          <button
            type="submit"
            disabled={isLoading}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:bg-blue-300"
          >
            Send
          </button>
        </div>
      </form>
    </div>
  )
}

