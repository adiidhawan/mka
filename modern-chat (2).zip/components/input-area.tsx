"use client"

import { useMemo } from "react"

import type React from "react"
import { useState, useRef, useEffect, useCallback, memo } from "react"
import { X, ArrowUp, Mic } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { WaveformVisualization } from "@/components/waveform-visualization"
import { useTheme } from "@/contexts/ThemeContext"
import Image from "next/image"

interface InputAreaProps {
  isSidebarPinned: boolean
  selectedMachines: Array<{ id: string; name: string; icon: string }> | []
  isRecording: boolean
  recordingTime: number
  handleSubmit: (message: string) => void
  handleRecordingSubmit: () => void
  startRecording: () => void
  stopRecording: () => void
  cancelRecording: () => void
  isInitialState: boolean
  setIsInitialState: (value: boolean) => void
  greeting: string
}

// Extracted StatusDot component for better memoization
const StatusDot = memo(({ isSelected }: { isSelected: boolean }) => (
  <div className={cn("w-2 h-2 rounded-full mr-2 animate-pulse", isSelected ? "bg-green-500" : "bg-red-500")} />
))

StatusDot.displayName = "StatusDot"

// Extracted MachineStatus component for better memoization
const MachineStatus = memo(
  ({
    selectedMachines,
  }: {
    selectedMachines: Array<{ id: string; name: string; icon: string }> | []
  }) => (
    <div className="flex items-center justify-center text-xs text-gray-600 dark:text-gray-300 ml-4">
      <StatusDot isSelected={selectedMachines.length > 0} />
      <span>
        {selectedMachines.length > 0 ? (
          <>
            You are enquiring about:{" "}
            <span className="inline-flex items-center">
              <Image
                src={selectedMachines[0].icon || "/placeholder.svg"}
                alt={selectedMachines[0].name}
                width={16}
                height={16}
                className="inline-block mr-1"
                loading="lazy"
              />
              {selectedMachines[0].name}
            </span>
          </>
        ) : (
          "No machine selected"
        )}
      </span>
    </div>
  ),
)

MachineStatus.displayName = "MachineStatus"

// Extracted RecordingControls component for better memoization
const RecordingControls = memo(
  ({
    isRecording,
    recordingTime,
    message,
    handleRecordingSubmit,
    handleSubmit,
    startRecording,
    cancelRecording,
    isDisabled,
  }: {
    isRecording: boolean
    recordingTime: number
    message: string
    handleRecordingSubmit: () => void
    handleSubmit: () => void
    startRecording: () => void
    cancelRecording: () => void
    isDisabled: boolean
  }) => {
    const [showStoppedMessage, setShowStoppedMessage] = useState(false)

    const handleCancelRecording = useCallback(() => {
      cancelRecording()
      setShowStoppedMessage(true)
      setTimeout(() => setShowStoppedMessage(false), 2000)
    }, [cancelRecording])

    return (
      <div className="ml-auto flex items-center gap-2">
        {isRecording && (
          <>
            <div
              className="text-red-500 text-sm font-medium mr-2"
              style={{
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
                textShadow: "0 0 5px rgba(255, 0, 0, 0.7)",
                fontSize: "15px",
                letterSpacing: "0.5px",
              }}
            >
              {Math.floor(recordingTime / 60)
                .toString()
                .padStart(2, "0")}
              :{(recordingTime % 60).toString().padStart(2, "0")}
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={handleCancelRecording}
              className="h-12 w-12 rounded-full bg-red-500 text-white hover:bg-red-600 transition-colors duration-200"
            >
              <X className="h-6 w-6" />
            </Button>
          </>
        )}
        {showStoppedMessage && (
          <div className="text-green-500 text-sm font-medium mr-2 animate-fade-out">Recording stopped</div>
        )}
        <Button
          type="submit"
          variant="ghost"
          size="icon"
          className={cn(
            "h-12 w-12 rounded-full transition-all duration-400 ease-in-out relative overflow-hidden",
            isRecording
              ? "bg-[#8B4513] text-white hover:bg-[#A0522D] shadow-[0_0_10px_rgba(255,140,0,0.7)]"
              : message.trim()
                ? "bg-[#C66A3F] text-white hover:bg-[#B55A2F] shadow-[0_0_10px_rgba(255,140,0,0.7)]"
                : "bg-[#87CEFA] text-gray-700 hover:bg-[#5F9EA0] shadow-[0_0_15px_rgba(135,206,250,0.7)]",
            isDisabled && "opacity-50 cursor-not-allowed",
          )}
          disabled={isDisabled}
        >
          <div className="relative z-10">
            {isRecording ? (
              <ArrowUp className="h-9 w-9" strokeWidth={2.5} />
            ) : message.trim() ? (
              <ArrowUp className="h-9 w-9" strokeWidth={2.5} />
            ) : (
              <Mic className="h-9 w-9" strokeWidth={2.5} />
            )}
          </div>
          {!isRecording && !message.trim() && (
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-shine" />
          )}
        </Button>
      </div>
    )
  },
)

RecordingControls.displayName = "RecordingControls"

export const InputArea: React.FC<InputAreaProps> = memo(
  ({
    isSidebarPinned,
    selectedMachines,
    isRecording,
    recordingTime,
    handleSubmit,
    handleRecordingSubmit,
    startRecording,
    stopRecording,
    cancelRecording,
    isInitialState,
    setIsInitialState,
    greeting,
  }) => {
    const [message, setMessage] = useState("")
    const textareaRef = useRef<HTMLTextAreaElement>(null)
    const { theme } = useTheme()
    const resizeTimeoutRef = useRef<NodeJS.Timeout | null>(null)

    // Fix for ResizeObserver loop error - use a simpler approach for textarea resizing
    useEffect(() => {
      const textarea = textareaRef.current
      if (!textarea) return

      // Simple function to adjust height without using ResizeObserver
      const adjustHeight = () => {
        // Reset height to auto to get the correct scrollHeight
        textarea.style.height = "auto"

        // Set the height based on scrollHeight with a maximum
        const newHeight = Math.min(textarea.scrollHeight, 200)
        textarea.style.height = `${newHeight}px`
      }

      // Debounce the resize to prevent too many calculations
      const debouncedAdjustHeight = () => {
        if (resizeTimeoutRef.current) {
          clearTimeout(resizeTimeoutRef.current)
        }

        resizeTimeoutRef.current = setTimeout(() => {
          adjustHeight()
        }, 10)
      }

      // Add event listeners
      textarea.addEventListener("input", debouncedAdjustHeight)

      // Initial adjustment
      adjustHeight()

      // Cleanup
      return () => {
        textarea.removeEventListener("input", debouncedAdjustHeight)
        if (resizeTimeoutRef.current) {
          clearTimeout(resizeTimeoutRef.current)
        }
      }
    }, [])

    const handleKeyDown = useCallback(
      (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault()
          if (selectedMachines.length > 0 && message.trim()) {
            handleSubmit(message)
            setMessage("")
            setIsInitialState(false)
          }
        }
      },
      [message, selectedMachines, handleSubmit, setIsInitialState],
    )

    const handleFormSubmit = useCallback(
      (e: React.FormEvent) => {
        e.preventDefault()
        if (isRecording) {
          handleRecordingSubmit()
        } else if (message.trim() && selectedMachines.length > 0) {
          handleSubmit(message)
          setMessage("")
          setIsInitialState(false)
        } else if (!isRecording && !message.trim() && selectedMachines.length > 0) {
          startRecording()
        }
      },
      [isRecording, message, selectedMachines, handleRecordingSubmit, handleSubmit, startRecording, setIsInitialState],
    )

    const inputAreaClasses = useMemo(
      () =>
        cn(
          "w-full transition-all duration-300",
          isInitialState
            ? "max-w-3xl mx-auto px-4"
            : cn(
                "fixed bottom-0 right-0 bg-white dark:bg-[#141619] transition-[left,margin] duration-300 ease-in-out",
                isSidebarPinned ? "left-80" : "left-0",
              ),
        ),
      [isInitialState, isSidebarPinned],
    )

    // Handle textarea value change with height adjustment
    const handleTextareaChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setMessage(e.target.value)

      // Manually adjust height on change
      const textarea = e.target
      textarea.style.height = "auto"
      textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`
    }, [])

    return (
      <div className={inputAreaClasses}>
        <div className={cn("mx-auto", isInitialState ? "max-w-2xl" : isSidebarPinned ? "max-w-3xl ml-2" : "max-w-3xl")}>
          <form
            onSubmit={handleFormSubmit}
            className={cn(
              "px-4 py-3 backdrop-blur-sm transition-all duration-400 ease-in-out",
              isInitialState
                ? "rounded-[12px] shadow-[0_0_20px_rgba(167,139,250,0.5)] bg-white/10 dark:bg-gray-800/30 hover:shadow-[0_0_30px_rgba(167,139,250,0.7)] focus-within:shadow-[0_0_40px_rgba(167,139,250,0.9)]"
                : "rounded-t-[12px] bg-[#E6F3FF] dark:bg-[#281E5D]",
            )}
          >
            <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400">
              <MachineStatus selectedMachines={selectedMachines} />

              <RecordingControls
                isRecording={isRecording}
                recordingTime={recordingTime}
                message={message}
                handleRecordingSubmit={handleRecordingSubmit}
                handleSubmit={() => {
                  if (message.trim() && selectedMachines.length > 0) {
                    handleSubmit(message)
                    setMessage("")
                    setIsInitialState(false)
                  } else if (selectedMachines.length > 0) {
                    startRecording()
                  }
                }}
                startRecording={startRecording}
                cancelRecording={cancelRecording}
                isDisabled={selectedMachines.length === 0}
              />
            </div>

            {isRecording && (
              <div className="flex items-center justify-center h-16 mb-2 px-4">
                <WaveformVisualization />
              </div>
            )}

            {!isRecording && (
              <div className="relative mt-2">
                {selectedMachines.length === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-md z-10">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Select a machine from the dropdown, please
                    </p>
                  </div>
                )}
                <textarea
                  ref={textareaRef}
                  value={message}
                  onChange={handleTextareaChange}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask me anything"
                  className={cn(
                    "min-h-[24px] w-full resize-none bg-transparent text-[15px] outline-none custom-scrollbar",
                    theme === "light" ? "text-gray-800" : "text-gray-200",
                    "placeholder:text-gray-400",
                  )}
                  disabled={selectedMachines.length === 0}
                  rows={1}
                />
              </div>
            )}
          </form>
        </div>
      </div>
    )
  },
)

InputArea.displayName = "InputArea"

