"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useTheme } from "@/contexts/ThemeContext"
import { X, ChevronLeft, ChevronRight, Download } from "lucide-react"

// Sample user guide content divided into pages
const USER_GUIDE_CONTENT = [
  {
    title: "Maintenance Mitra User Guide",
    content: [
      "Welcome to Maintenance Mitra, your AI-powered assistant for industrial equipment maintenance.",
      "This guide will help you understand how to use the application effectively and get the most out of its features.",
      "Navigate through the pages using the controls at the bottom of this window.",
    ],
  },
  {
    title: "Getting Started",
    content: [
      "1. Select a machine from the dropdown menu at the top of the screen",
      "2. Type your question in the input field or use the microphone button to record your query",
      "3. Review the AI-generated response",
      "4. Provide feedback using the reaction buttons below each response",
      "5. Access your chat history from the sidebar",
    ],
  },
  {
    title: "Machine Selection",
    content: [
      "The machine selection dropdown allows you to specify which equipment you're inquiring about.",
      "Available machines include:",
      "• Conveyor",
      "• ED Oven",
      "• Paint Robot",
      "• Sealer Oven",
      "• Topcoat Oven",
      "• Wax Robot",
      "Selecting a machine helps the AI provide more accurate and relevant information.",
    ],
  },
  {
    title: "Voice Input",
    content: [
      "To use voice input:",
      "1. Click the microphone icon in the input area",
      "2. Speak clearly into your microphone",
      "3. The recording will be automatically transcribed",
      "4. Review the transcription before sending",
      "5. Click the send button to submit your query",
      "You can cancel a recording at any time by clicking the X button.",
    ],
  },
  {
    title: "Feedback System",
    content: [
      "After receiving a response, you can provide feedback using the reaction buttons:",
      "• Thumbs Up: Good response",
      "• Double Thumbs Up: Great response",
      "• Thumbs Down: Bad response",
      "When you select a reaction, you'll be prompted to provide more detailed feedback.",
      "Your feedback helps improve the system for everyone.",
    ],
  },
  {
    title: "Chat History",
    content: [
      "Your conversations are saved automatically and can be accessed from the sidebar.",
      "To open the sidebar, click the menu icon in the bottom left corner.",
      "From the sidebar, you can:",
      "• View past conversations",
      "• Star important chats",
      "• Rename chats for better organization",
      "• Delete unwanted conversations",
    ],
  },
  {
    title: "Theme Settings",
    content: [
      "Maintenance Mitra supports both light and dark themes.",
      "To change the theme:",
      "1. Click on your profile icon in the bottom right corner",
      "2. Toggle between light and dark mode using the switch",
      "Your preference will be saved for future sessions.",
    ],
  },
]

interface UserGuideDialogProps {
  onClose: () => void
}

export function UserGuideDialog({ onClose }: UserGuideDialogProps) {
  const { theme } = useTheme()
  const [pageNumber, setPageNumber] = useState<number>(1)
  const numPages = USER_GUIDE_CONTENT.length

  function changePage(offset: number) {
    setPageNumber((prevPageNumber) => {
      const newPageNumber = prevPageNumber + offset
      return Math.max(1, Math.min(numPages, newPageNumber))
    })
  }

  function previousPage() {
    changePage(-1)
  }

  function nextPage() {
    changePage(1)
  }

  // Get current page content
  const currentPage = USER_GUIDE_CONTENT[pageNumber - 1]

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-4xl h-[85vh] px-4">
        <div
          className={cn(
            "relative rounded-[20px] h-full flex flex-col backdrop-blur-sm border shadow-lg",
            theme === "light"
              ? "bg-[#E6F3FF] border-blue-200 text-gray-800"
              : "bg-[#281E5D] border-gray-700/50 text-white",
          )}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-xl font-semibold">User Guide</h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="rounded-full h-8 w-8 hover:bg-gray-200 dark:hover:bg-gray-700"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Content Viewer */}
          <div className="flex-1 overflow-auto p-6">
            <div className={cn("min-h-full rounded-lg p-8 shadow-lg", theme === "light" ? "bg-white" : "bg-gray-800")}>
              <h1 className="text-2xl font-bold mb-6">{currentPage.title}</h1>

              <div className="space-y-4">
                {currentPage.content.map((paragraph, index) => (
                  <p key={index} className="text-base leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </div>

              <div className="mt-8 text-sm text-gray-500 dark:text-gray-400 text-right">
                Page {pageNumber} of {numPages}
              </div>
            </div>
          </div>

          {/* Footer with pagination controls */}
          <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700">
            <div className="text-sm">{`Page ${pageNumber} of ${numPages}`}</div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={previousPage}
                disabled={pageNumber <= 1}
                className={cn(
                  "rounded-full",
                  theme === "light" ? "border-gray-300 hover:bg-gray-100" : "border-gray-700 hover:bg-gray-800",
                )}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={nextPage}
                disabled={pageNumber >= numPages}
                className={cn(
                  "rounded-full",
                  theme === "light" ? "border-gray-300 hover:bg-gray-100" : "border-gray-700 hover:bg-gray-800",
                )}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.print()}
                className={cn(
                  "rounded-full ml-2",
                  theme === "light"
                    ? "bg-blue-500 text-white hover:bg-blue-600 border-blue-500"
                    : "bg-[#C66A3F] text-white hover:bg-[#B55A2F] border-[#C66A3F]",
                )}
              >
                <Download className="h-4 w-4 mr-1" />
                Print
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

