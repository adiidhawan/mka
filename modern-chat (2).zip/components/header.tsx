"use client"

import { cn } from "@/lib/utils"
import { useTheme } from "@/contexts/ThemeContext"

interface HeaderProps {
  className?: string
}

export function Header({ className }: HeaderProps) {
  const { theme } = useTheme()

  return (
    <header
      className={cn(
        "fixed top-0 left-0 w-full h-[31.347px] z-50 backdrop-blur-[8px]",
        theme === "light" ? "bg-white" : "bg-[#1A1D21]/95",
        className,
      )}
    >
      {/* Subtle top highlight */}
      <div
        className={cn(
          "absolute top-0 left-0 right-0 h-px bg-gradient-to-r",
          theme === "light"
            ? "from-transparent via-gray-200/50 to-transparent"
            : "from-transparent via-gray-700/50 to-transparent",
        )}
      />

      {/* Main header content */}
      <div className="w-full h-full px-4">
        <div className="relative flex h-full items-center justify-between transition-colors duration-300">
          {/* Left logo */}
          <div className="absolute left-4 top-1/2 -translate-y-1/2 transition-opacity duration-300">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/TopSopt%20Logo%201-gV7FjZPnewnWKuvBF1pkxrvVb1RQm7.png"
              alt="TopSpot"
              className={`h-[28px] w-auto ${theme === "dark" ? "opacity-90" : "opacity-100"}`}
            />
          </div>

          {/* Center title */}
          <h1 className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[20px] font-semibold tracking-tight transition-colors duration-300">
            <span
              className={`relative bg-gradient-to-r from-[#4169E1] via-[#87CEFA] to-[#4169E1] bg-[400%_auto] animate-enhanced-flow bg-clip-text text-transparent transition-shadow duration-300 ${
                theme === "dark"
                  ? "[text-shadow:0_1px_5px_rgba(65,105,225,0.2)]"
                  : "[text-shadow:0_1px_5px_rgba(65,105,225,0.1)]"
              }`}
            >
              Maintainence Mitra
            </span>
          </h1>

          {/* Right logo */}
          <div className="absolute right-4 top-1/2 -translate-y-1/2 transition-opacity duration-300">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/TML%20Logo%201-Np8D8G5mmbZqj3yf9uroDoL8gDrhBo.png"
              alt="Tata Motors"
              className={`h-[42px] w-auto ${theme === "dark" ? "opacity-90" : "opacity-100"}`}
            />
          </div>
        </div>
      </div>

      {/* Bottom border gradient */}
      <div
        className={cn(
          "absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r",
          theme === "light"
            ? "from-transparent via-gray-200/50 to-transparent"
            : "from-transparent via-gray-700/50 to-transparent",
        )}
      />
    </header>
  )
}

