"use client"

import React from "react"
import { cn } from "@/lib/utils"

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link" | "viewChats" | "close"
  size?: "default" | "sm" | "lg" | "icon"
  className?: string
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, ...props }, ref) => {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        variant === "default"
          ? "bg-primary text-primary-foreground hover:bg-primary/90"
          : variant === "destructive"
            ? "bg-destructive text-destructive-foreground hover:bg-destructive/90"
            : variant === "outline"
              ? "bg-transparent border border-input hover:bg-accent hover:text-accent-foreground"
              : variant === "secondary"
                ? "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                : variant === "ghost"
                  ? "hover:bg-accent hover:text-accent-foreground"
                  : variant === "link"
                    ? "underline-offset-4 hover:underline text-primary"
                    : variant === "viewChats"
                      ? "rounded-full px-4 py-2 w-auto ml-auto dark:bg-white dark:text-black light:bg-black light:text-white hover:opacity-90"
                      : variant === "close"
                        ? "rounded-md px-5 py-2.5 text-base font-medium bg-black text-white dark:bg-white dark:text-black hover:bg-black/90 dark:hover:bg-white/90"
                        : "",
        size === "default"
          ? "h-10 px-4 py-2"
          : size === "sm"
            ? "h-9 rounded-md px-3"
            : size === "lg"
              ? "h-11 rounded-md px-8"
              : size === "icon"
                ? "h-10 w-10"
                : "",
        className,
      )}
      ref={ref}
      type="button"
      {...props}
    >
      {variant === "close" && !props.children ? "Close" : props.children}
    </button>
  )
})
Button.displayName = "Button"

export { Button }

