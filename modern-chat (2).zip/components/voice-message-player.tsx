"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause } from "lucide-react"

interface VoiceMessagePlayerProps {
  audioUrl: string
}

export const VoiceMessagePlayer: React.FC<VoiceMessagePlayerProps> = ({ audioUrl }) => {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement>(null)
  const [waveformData, setWaveformData] = useState<number[]>([])

  useEffect(() => {
    const loadAudio = async () => {
      try {
        setIsLoading(true)
        setError(null)

        const response = await fetch(audioUrl)
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const blob = await response.blob()
        const audioContext = new AudioContext()

        if (!audioContext.decodeAudioData) {
          throw new Error("Audio decoding not supported in this browser.")
        }

        const arrayBuffer = await blob.arrayBuffer()
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer)

        const channelData = audioBuffer.getChannelData(0)
        const samples = 20
        const blockSize = Math.floor(channelData.length / samples)
        const waveform = []

        for (let i = 0; i < samples; i++) {
          const start = blockSize * i
          const end = start + blockSize
          const chunk = channelData.slice(start, end)
          const value = chunk.reduce((sum, val) => sum + Math.abs(val), 0) / chunk.length
          waveform.push(value)
        }

        setWaveformData(waveform)
        setIsLoading(false)
      } catch (err) {
        console.error("Error loading audio:", err)
        setError(err instanceof Error ? err.message : "Unable to load audio")
        setIsLoading(false)
      }
    }

    loadAudio()
  }, [audioUrl])

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.src = audioUrl
    }
  }, [audioUrl])

  useEffect(() => {
    return () => {
      if (audioRef.current && audioRef.current.src) {
        URL.revokeObjectURL(audioRef.current.src)
      }
    }
  }, [])

  if (error) {
    return <div className="flex items-center justify-center p-4 text-red-500">{error}</div>
  }

  return (
    <div className="flex flex-col w-full gap-2 p-2">
      <div className="flex items-center gap-3">
        <Button
          onClick={togglePlayPause}
          variant="ghost"
          size="icon"
          disabled={isLoading}
          className="h-8 w-8 rounded-full bg-[#4169E1] text-white hover:bg-[#3154B3] flex-shrink-0 disabled:opacity-50"
        >
          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </Button>
        <div className="flex-grow h-12 bg-[#281E5D]/50 rounded-lg overflow-hidden">
          {isLoading ? (
            <div className="w-full h-full flex items-center justify-center">
              <div className="animate-pulse bg-[#4169E1]/20 w-full h-2" />
            </div>
          ) : (
            <div className="flex items-center justify-center w-full h-12">
              {waveformData.map((level, index) => (
                <div key={index} className="w-1 mx-px h-full flex items-center justify-center group">
                  <div
                    className="w-full bg-gradient-to-b from-[#4169E1] to-[#87CEFA] rounded-full transition-all duration-100 ease-in-out group-hover:from-[#3154B3] group-hover:to-[#5F9EA0]"
                    style={{
                      height: `${level * 100}%`,
                      transform: `scaleY(${0.3 + level * 0.7})`,
                    }}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <audio
        ref={audioRef}
        onEnded={() => setIsPlaying(false)}
        onError={(e) => {
          console.error("Audio playback error:", e)
          setError("Error playing audio")
        }}
      />
    </div>
  )
}

