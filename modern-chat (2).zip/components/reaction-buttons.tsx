"use client"

import React, { useCallback, useMemo } from "react"
import { Copy, ThumbsUp, ThumbsDown, Volume2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface ReactionButtonsProps {
  msgId: string
  content: string
  activeReactions: { [key: string]: string }
  pendingReactions?: { [key: string]: string }
  handleReactionClick: (msgId: string, reactionType: string, isActive: boolean) => void
  theme: string
  playTextToSpeech?: (text: string) => void
  selectedMachine?: {
    id: string
    name: string
    icon: string
  } | null
}

const DoubleThumbsUp = React.memo(
  ({ className, colorLeft, colorRight }: { className?: string; colorLeft?: string; colorRight?: string }) => (
    <div className={cn("relative w-4 h-3 flex items-center", className)}>
      <ThumbsUp className={cn("absolute left-0", colorLeft)} size={14} strokeWidth={1.75} fill="currentColor" />
      <ThumbsUp className={cn("absolute left-1.5", colorRight)} size={14} strokeWidth={1.75} fill="currentColor" />
    </div>
  ),
)

DoubleThumbsUp.displayName = "DoubleThumbsUp"

// Extracted ReactionButton component for better memoization
const ReactionButton = React.memo(
  ({
    reaction,
    isActive,
    onClick,
    theme,
  }: {
    reaction: any
    isActive: boolean
    onClick: () => void
    theme: string
  }) => {
    return (
      <div className="group relative">
        <button
          onClick={onClick}
          className={cn(
            "p-1 rounded-full transition-all duration-400 ease-in-out hover:scale-110 focus:outline-none",
            isActive ? reaction.activeColor : reaction.inactiveColor,
          )}
        >
          {reaction.icon === DoubleThumbsUp ? (
            <DoubleThumbsUp
              className={isActive ? "" : reaction.inactiveColor}
              colorLeft={isActive ? reaction.specialColors?.light : undefined}
              colorRight={isActive ? reaction.specialColors?.dark : undefined}
            />
          ) : (
            <reaction.icon className="w-3.5 h-3.5" strokeWidth={1.75} fill="currentColor" />
          )}
        </button>
        <div className="absolute right-0 top-0 px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white">
          {reaction.label}
          {isActive && " (active)"}
        </div>
      </div>
    )
  },
)

ReactionButton.displayName = "ReactionButton"

export const ReactionButtons: React.FC<ReactionButtonsProps> = React.memo(
  ({ msgId, content, activeReactions, handleReactionClick, theme, playTextToSpeech, selectedMachine }) => {
    const [copiedMessageId, setCopiedMessageId] = React.useState<string | null>(null)

    // Memoize reactions configuration to avoid recreating on each render
    const reactions = useMemo(
      () => [
        {
          icon: ThumbsUp,
          label: "Good response",
          key: "like",
          activeColor: "text-green-500",
          inactiveColor: theme === "light" ? "text-gray-600" : "text-gray-400",
        },
        {
          icon: DoubleThumbsUp,
          label: "Great response",
          key: "love",
          activeColor: "text-blue-500",
          inactiveColor: theme === "light" ? "text-gray-600" : "text-gray-400",
          specialColors: {
            light: "text-blue-300",
            dark: "text-blue-700",
          },
        },
        {
          icon: ThumbsDown,
          label: "Bad response",
          key: "dislike",
          activeColor: "text-red-500",
          inactiveColor: theme === "light" ? "text-gray-600" : "text-gray-400",
        },
      ],
      [theme],
    )

    // Memoize copy handler to avoid recreating on each render
    const handleCopyClick = useCallback(() => {
      navigator.clipboard.writeText(content).then(() => {
        setCopiedMessageId(msgId)
        setTimeout(() => setCopiedMessageId(null), 1000)
      })
    }, [content, msgId])

    // Memoize the audio handler to avoid recreating on each render
    const handleAudioClick = useCallback(() => {
      if (playTextToSpeech) {
        playTextToSpeech(content)
      }
    }, [playTextToSpeech, content])

    return (
      <div className="flex justify-between items-center mt-1 pr-4 pl-10">
        <div className="flex items-center gap-1">
          {reactions.map((reaction) => {
            const isActive = activeReactions[msgId] === reaction.key

            // Create a memoized click handler for each reaction
            const handleClick = useCallback(() => {
              handleReactionClick(msgId, reaction.key, isActive)
            }, [reaction.key, isActive])

            return (
              <ReactionButton
                key={reaction.key}
                reaction={reaction}
                isActive={isActive}
                onClick={handleClick}
                theme={theme}
              />
            )
          })}

          {playTextToSpeech && (
            <div className="group relative">
              <button
                onClick={handleAudioClick}
                className={cn(
                  "p-1 rounded-full transition-all duration-300 hover:scale-110 focus:outline-none",
                  theme === "light" ? "text-gray-600" : "text-gray-400",
                )}
              >
                <Volume2 className="w-3.5 h-3.5" strokeWidth={1.75} />
              </button>
              <div className="absolute right-0 top-0 px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white">
                Play audio
              </div>
            </div>
          )}

          <div className="group relative">
            <button
              onClick={handleCopyClick}
              className={cn(
                "p-1 rounded-full transition-all duration-300 hover:scale-110 focus:outline-none",
                copiedMessageId === msgId ? "text-yellow-500" : theme === "light" ? "text-gray-600" : "text-gray-400",
              )}
            >
              <Copy className="w-3.5 h-3.5" strokeWidth={1.75} />
            </button>
            <div className="absolute right-0 top-0 px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white">
              {copiedMessageId === msgId ? "Copied!" : "Copy"}
            </div>
          </div>
        </div>

        {selectedMachine && (
          <div className="flex items-center text-xs opacity-70 ml-6 italic">
            <span>Response generated about {selectedMachine.name}</span>
            {selectedMachine.icon && (
              <img
                src={selectedMachine.icon || "/placeholder.svg"}
                alt={selectedMachine.name}
                className="w-3 h-3 object-contain ml-1"
                loading="lazy"
              />
            )}
          </div>
        )}
      </div>
    )
  },
)

ReactionButtons.displayName = "ReactionButtons"

