"use client"

import { useState, useRef, useEffect } from "react"
import { useChat } from "ai/react"
import { Paperclip, ChevronDown, Globe, Mic, ArrowUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

const EXAMPLE_MESSAGES = [
  // Initial greeting message removed from here
]

export function ChatWidget() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat()
  const [message, setMessage] = useState("")
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const textarea = textareaRef.current
    if (!textarea) return

    const adjustHeight = () => {
      textarea.style.height = "auto"
      const newHeight = Math.min(textarea.scrollHeight, 200)
      textarea.style.height = `${newHeight}px`
    }

    textarea.addEventListener("input", adjustHeight)
    adjustHeight()

    return () => textarea.removeEventListener("input", adjustHeight)
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  return (
    <div className="relative h-full w-full overflow-hidden rounded-[20px] bg-[#2D2D2D]/80 backdrop-blur-sm flex flex-col">
      {/* Messages Area */}
      <div className="flex-grow overflow-y-auto px-4 pb-4">
        <div className="space-y-4 pt-4">
          {messages.map((msg, index) => (
            <div key={msg.id || index} className="flex items-start">
              <div
                className={cn(
                  "relative w-full rounded-[20px] py-4 text-[15px] leading-relaxed text-white backdrop-blur-sm",
                  msg.role === "user" ? "bg-[#1a2942]/95" : "bg-[#333333]/95",
                )}
                style={{
                  fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
                }}
              >
                {msg.role === "user" && (
                  <div className="absolute left-4 top-1/2 h-8 w-8 -translate-y-1/2 rounded-full bg-[#4169E1] text-sm font-medium text-white">
                    <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                      {msg.avatar || "U"}
                    </span>
                  </div>
                )}
                <div className={msg.role === "user" ? "pl-16 pr-6" : "px-6"}>{msg.content}</div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="w-full">
        <div className="rounded-t-[12px] rounded-b-none bg-[#1a2942]/95 px-4 py-3 backdrop-blur-sm">
          <div className="flex items-center gap-3 text-gray-400">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="h-auto p-0 text-[15px] font-normal text-gray-400 hover:bg-transparent hover:text-gray-300"
                  style={{
                    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
                  }}
                >
                  <Globe className="mr-2 h-4 w-4" />
                  Language
                  <ChevronDown className="ml-1 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-[#1a2942] border-gray-700">
                <DropdownMenuItem className="text-gray-300 focus:bg-[#2a3b56] focus:text-gray-200">
                  English
                </DropdownMenuItem>
                <DropdownMenuItem className="text-gray-300 focus:bg-[#2a3b56] focus:text-gray-200">
                  Spanish
                </DropdownMenuItem>
                <DropdownMenuItem className="text-gray-300 focus:bg-[#2a3b56] focus:text-gray-200">
                  French
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="ml-auto flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-auto p-0 text-gray-400 hover:bg-transparent hover:text-gray-300"
              >
                <Paperclip className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "h-8 w-8 rounded-full transition-colors",
                  message.length > 0
                    ? "bg-[#8B4513] hover:bg-[#A0522D] text-white"
                    : "text-gray-400 hover:text-gray-300",
                )}
              >
                {message.length > 0 ? <ArrowUp className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="relative mt-2">
            <textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter text here"
              className="min-h-[24px] max-h-[200px] w-full resize-none bg-transparent text-[15px] text-gray-200 placeholder-gray-500 outline-none scrollbar-thin scrollbar-track-transparent scrollbar-thumb-gray-600"
              style={{
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
              }}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

