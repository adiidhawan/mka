import { ThumbsUpIcon as LucideThumbUp } from "lucide-react"

export default function ThumbsUp({ className, ...props }: { className?: string; strokeWidth?: number }) {
  return <LucideThumbUp className={className} strokeWidth={props.strokeWidth ?? 1.75} {...props} />
}

