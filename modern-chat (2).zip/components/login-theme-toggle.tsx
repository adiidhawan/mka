"use client"

import React from "react"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "@/contexts/ThemeContext"
import { cn } from "@/lib/utils"

export const LoginThemeToggle: React.FC = React.memo(() => {
  const { theme, toggleTheme } = useTheme()

  return (
    <div
      className={cn(
        "flex flex-col items-center gap-2 p-4 rounded-xl backdrop-blur-sm shadow-lg transition-colors",
        theme === "light" ? "bg-white/80 hover:bg-white/90" : "bg-[#1a2942]/80 hover:bg-[#1a2942]/90",
      )}
    >
      <div
        className={cn(
          "w-14 h-8 rounded-full p-1 transition-all duration-300 ease-in-out cursor-pointer relative",
          theme === "light" ? "bg-white border border-gray-200" : "bg-gray-800 border border-gray-700",
        )}
        onClick={toggleTheme}
      >
        <div
          className={cn(
            "absolute w-6 h-6 rounded-full transition-all duration-300 ease-in-out flex items-center justify-center",
            theme === "dark" ? "right-1 bg-gray-700 text-gray-300" : "left-1 bg-gray-100 text-yellow-500",
          )}
        >
          {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
        </div>
      </div>
      <span className="text-xs font-medium text-gray-400 mt-2">{theme === "dark" ? "Dark mode" : "Light mode"}</span>
    </div>
  )
})

LoginThemeToggle.displayName = "LoginThemeToggle"

