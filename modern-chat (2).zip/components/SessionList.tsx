"use client"

import type React from "react"
import { useState } from "react"
import { useChat } from "@/hooks/useChat"

export const SessionList: React.FC = () => {
  const { sessions, currentSession, switchSession, createSession, renameSession, deleteSession } = useChat()
  const [newSessionName, setNewSessionName] = useState("")
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null)
  const [editingSessionName, setEditingSessionName] = useState("")

  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault()
    if (newSessionName.trim()) {
      createSession(newSessionName.trim())
      setNewSessionName("")
    }
  }

  const handleRenameSession = (id: string) => {
    if (editingSessionName.trim()) {
      renameSession(id, editingSessionName.trim())
      setEditingSessionId(null)
      setEditingSessionName("")
    }
  }

  return (
    <div className="p-4 border-r h-full">
      <h2 className="text-xl font-bold mb-4">Chat Sessions</h2>
      <form onSubmit={handleCreateSession} className="mb-4">
        <div className="flex space-x-2">
          <input
            type="text"
            value={newSessionName}
            onChange={(e) => setNewSessionName(e.target.value)}
            className="flex-1 px-3 py-2 border rounded-lg"
            placeholder="New session name..."
          />
          <button type="submit" className="px-4 py-2 bg-green-500 text-white rounded-lg">
            Create
          </button>
        </div>
      </form>
      <ul className="space-y-2">
        {sessions.map((session) => (
          <li
            key={session.id}
            className={`p-2 rounded-lg cursor-pointer ${
              currentSession?.id === session.id ? "bg-blue-100" : "hover:bg-gray-100"
            }`}
          >
            {editingSessionId === session.id ? (
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={editingSessionName}
                  onChange={(e) => setEditingSessionName(e.target.value)}
                  className="flex-1 px-2 py-1 border rounded"
                />
                <button
                  onClick={() => handleRenameSession(session.id)}
                  className="px-2 py-1 bg-blue-500 text-white rounded"
                >
                  Save
                </button>
              </div>
            ) : (
              <div className="flex justify-between items-center">
                <span onClick={() => switchSession(session.id)}>{session.name}</span>
                <div className="space-x-2">
                  <button
                    onClick={() => {
                      setEditingSessionId(session.id)
                      setEditingSessionName(session.name)
                    }}
                    className="text-blue-500"
                  >
                    Edit
                  </button>
                  <button onClick={() => deleteSession(session.id)} className="text-red-500">
                    Delete
                  </button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

