"use client"

import type React from "react"
import { useState } from "react"
import { Star, PlusCircle } from "lucide-react"

interface ChatItem {
  id: string
  title: string
  isStarred: boolean
}

interface ChatHeaderProps {
  chat?: ChatItem | null
  onToggleStar?: (chatId: string) => void
  onNewChat: () => void
  onRename: (chatId: string, newTitle: string) => void
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({ chat, onToggleStar, onNewChat, onRename }) => {
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false)
  const [editedTitle, setEditedTitle] = useState(chat?.title || "")

  const handleRename = () => {
    if (editedTitle.trim() && chat) {
      onRename(chat.id, editedTitle.trim())
      setIsRenameDialogOpen(false)
    }
  }

  return (
    <div className="flex items-center justify-between p-4 bg-gray-100">
      <div className="flex items-center space-x-4">
        <h2 className="text-lg font-semibold cursor-pointer" onClick={() => setIsRenameDialogOpen(true)}>
          {chat?.title || "New Chat"}
        </h2>
        <button
          className={`p-1 rounded-full ${chat?.isStarred ? "bg-yellow-400" : "bg-gray-200"}`}
          onClick={() => chat && onToggleStar?.(chat.id)}
        >
          <Star className="w-5 h-5" />
        </button>
      </div>
      <button className="px-4 py-2 bg-blue-500 text-white rounded-md" onClick={onNewChat}>
        <PlusCircle className="w-5 h-5 inline-block mr-2" />
        New Chat
      </button>

      {isRenameDialogOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-4">Rename Chat</h3>
            <input
              type="text"
              value={editedTitle}
              onChange={(e) => setEditedTitle(e.target.value)}
              className="w-full p-2 border rounded mb-4"
              placeholder="Enter new chat name"
            />
            <div className="flex justify-end space-x-2">
              <button onClick={() => setIsRenameDialogOpen(false)} className="px-4 py-2 bg-gray-200 rounded">
                Cancel
              </button>
              <button onClick={handleRename} className="px-4 py-2 bg-blue-500 text-white rounded">
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

