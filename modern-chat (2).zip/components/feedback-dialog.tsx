"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useTheme } from "@/contexts/ThemeContext"
import { Check } from "lucide-react"

interface FeedbackDialogProps {
  type: "good" | "great" | "bad"
  onClose: () => void
  onSubmit: (data: { type: string; details: string; reasons: string[] }) => void
}

const feedbackOptions = {
  good: [
    "Clear and concise",
    "Helpful information",
    "Quick response",
    "Accurate solution",
    "Well explained",
    "Easy to understand",
  ],
  great: [
    "Exceeded expectations",
    "Comprehensive answer",
    "Perfect solution",
    "Innovative approach",
    "Saved time",
    "Outstanding detail",
  ],
  bad: [
    "Incorrect information",
    "Instructions ignored",
    "Being lazy",
    "Don't like style",
    "Bad recommendation",
    "Other",
  ],
}

export function FeedbackDialog({ type, onClose, onSubmit }: FeedbackDialogProps) {
  const [details, setDetails] = useState("")
  const [selectedReasons, setSelectedReasons] = useState<string[]>([])
  const { theme } = useTheme()

  const handleReasonClick = (reason: string) => {
    setSelectedReasons((prev) => (prev.includes(reason) ? prev.filter((r) => r !== reason) : [...prev, reason]))
  }

  const handleSubmit = () => {
    onSubmit({
      type,
      details,
      reasons: selectedReasons,
    })
  }

  // Get title based on feedback type
  const getTitle = () => {
    switch (type) {
      case "good":
        return "Good Response"
      case "great":
        return "Great Response"
      case "bad":
        return "Bad Response"
      default:
        return "Feedback"
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-lg px-4">
        <div
          className={cn(
            "relative rounded-[20px] p-6 backdrop-blur-sm border shadow-lg",
            theme === "light"
              ? "bg-[#E6F3FF] border-blue-200 text-gray-800"
              : "bg-[#281E5D] border-gray-700/50 text-white",
          )}
        >
          <h3 className="mb-4 text-lg font-semibold">{getTitle()}</h3>

          <div className="mb-6">
            <p className="text-sm mb-3">What did you like about this response? Select all that apply.</p>
            <div className="grid grid-cols-2 gap-3">
              {feedbackOptions[type].map((reason) => (
                <button
                  key={reason}
                  onClick={() => handleReasonClick(reason)}
                  className={cn(
                    "flex items-center justify-between px-4 py-3 rounded-xl text-left text-sm transition-colors",
                    "border",
                    theme === "light"
                      ? selectedReasons.includes(reason)
                        ? "bg-blue-100 border-blue-300"
                        : "bg-white border-blue-200 hover:bg-blue-50"
                      : selectedReasons.includes(reason)
                        ? "bg-[#1E2A45] border-blue-500"
                        : "bg-[#1a2942] border-gray-700 hover:bg-[#1E2A45]",
                  )}
                >
                  <span>{reason}</span>
                  {selectedReasons.includes(reason) && <Check className="h-4 w-4 text-blue-500" />}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm mb-2">Additional comments (optional)</label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className={cn(
                "h-24 w-full resize-none rounded-[20px] p-4 text-sm placeholder-gray-500 border focus:outline-none",
                theme === "light"
                  ? "bg-[#F0F8FF] text-gray-800 border-blue-200 focus:border-blue-400"
                  : "bg-[#281E5D] text-gray-300 border-gray-700 focus:border-[#3b82f6]",
              )}
              placeholder="Your feedback..."
            />
          </div>

          <div className="flex justify-end gap-4">
            <Button
              variant="ghost"
              onClick={onClose}
              className={cn(
                "px-6",
                theme === "light"
                  ? "text-gray-600 hover:text-gray-800 hover:bg-blue-100"
                  : "text-gray-400 hover:text-gray-300 hover:bg-[#281E5D]",
              )}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              className={cn(
                "px-8 py-2.5 text-white",
                theme === "light" ? "bg-blue-500 hover:bg-blue-600" : "bg-[#C66A3F] hover:bg-[#B55A2F]",
              )}
            >
              Submit
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

