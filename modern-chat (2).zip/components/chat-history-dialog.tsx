"use client"

import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"
import { useState } from "react"
import { useTheme } from "@/contexts/ThemeContext"
import { cn } from "@/lib/utils"
import type { ChatItem } from "@/hooks/use-chat"

interface ChatHistoryDialogProps {
  isOpen: boolean
  onClose: () => void
  chats: ChatItem[]
  onSelect: (chat: ChatItem) => void
  onDelete: (chatId: string) => void
  onToggleStar: (chatId: string) => void
  onRename: (chatId: string, newTitle: string) => void
}

export function ChatHistoryDialog({
  isOpen,
  onClose,
  chats,
  onSelect,
  onDelete,
  onToggleStar,
  onRename,
}: ChatHistoryDialogProps) {
  const { theme } = useTheme()
  const [searchQuery, setSearchQuery] = useState("")
  const [editingChatId, setEditingChatId] = useState<string | null>(null)
  const [editedTitle, setEditedTitle] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [dialogType, setDialogType] = useState<"rename" | "delete" | null>(null)
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)

  const filteredChats = chats.filter(
    (chat) =>
      // Only show chats that have at least one user message
      chat.messages.some((msg) => msg.role === "user") &&
      // Apply search filter
      chat.title
        .toLowerCase()
        .includes(searchQuery.toLowerCase()),
  )

  const handleRename = (chatId: string) => {
    if (editedTitle.trim()) {
      onRename(chatId, editedTitle.trim())
      setEditingChatId(null)
      setEditedTitle("")
    }
  }

  const formatTimestamp = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)
    const months = Math.floor(days / 30)

    if (months > 0) return `${months} month${months === 1 ? "" : "s"} ago`
    if (days > 0) return `${days} day${days === 1 ? "" : "s"} ago`
    if (hours > 0) return `${hours} hour${hours === 1 ? "" : "s"} ago`
    if (minutes > 0) return `${minutes} minute${minutes === 1 ? "" : "s"} ago`
    return "Just now"
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <DialogContent
        className={cn(
          "max-w-4xl h-[85vh] p-0 gap-0 border-0",
          theme === "light" ? "bg-[#E6F3FF]" : "bg-[#141619]",
          "custom-close-button", // Add this class
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div
            className={cn(
              "flex items-center justify-between p-6",
              theme === "light" ? "bg-[#E6F3FF] border-b border-blue-200" : "bg-[#141619] border-b border-gray-800",
            )}
          >
            <h2 className={cn("text-2xl font-semibold", theme === "light" ? "text-gray-900" : "text-white")}>
              Chat History
            </h2>
            <Button
              onClick={onClose}
              className={cn(
                "rounded-lg px-5 py-2.5 text-base font-medium absolute right-2 top-2 z-50",
                theme === "light" ? "bg-black text-white hover:bg-gray-800" : "bg-white text-black hover:bg-gray-200",
              )}
            >
              Close
            </Button>
          </div>

          {/* Search */}
          <div className="p-6 pb-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search chats..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={cn(
                  "w-full pl-10 h-12 text-base",
                  theme === "light"
                    ? "bg-white/50 border-blue-200 text-gray-900 placeholder:text-gray-500"
                    : "bg-[#1a2942] border-gray-700 text-white placeholder:text-gray-400",
                )}
              />
              <Search
                className={cn(
                  "absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5",
                  theme === "light" ? "text-gray-500" : "text-gray-400",
                )}
              />
            </div>
          </div>

          {/* Chat List */}
          <div className="flex-1 overflow-y-auto p-6 pt-2">
            {filteredChats.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <p className={cn("text-2xl font-medium mb-2", theme === "light" ? "text-gray-600" : "text-gray-400")}>
                    No chats yet
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredChats.map((chat) => (
                  <div
                    key={chat.id}
                    className={cn(
                      "group relative rounded-xl p-4 transition-colors duration-200",
                      theme === "light" ? "bg-[#C2DBFF] hover:bg-[#B0CFFF]" : "bg-[#1E2A45] hover:bg-[#252F4A]",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        {editingChatId === chat.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              value={editedTitle}
                              onChange={(e) => setEditedTitle(e.target.value)}
                              className={cn(
                                "flex-1",
                                theme === "light" ? "bg-white border-blue-200" : "bg-[#281E5D] border-gray-700",
                              )}
                              autoFocus
                            />
                            <Button
                              size="sm"
                              onClick={() => handleRename(chat.id)}
                              className={cn(
                                theme === "light" ? "bg-blue-500 hover:bg-blue-600" : "bg-[#C66A3F] hover:bg-[#B55A2F]",
                              )}
                            >
                              Save
                            </Button>
                          </div>
                        ) : (
                          <>
                            <div
                              className={cn(
                                "text-lg font-medium truncate cursor-pointer hover:underline",
                                theme === "light" ? "text-gray-900" : "text-white",
                              )}
                              onClick={() => {
                                // Create a new Date object with a timestamp slightly in the future to ensure it's the most recent
                                const now = new Date()
                                now.setMilliseconds(now.getMilliseconds() + 100)

                                // Update the chat with the new date to make it the most recent chat
                                const updatedChat = {
                                  ...chat,
                                  date: now,
                                }

                                // Select the updated chat and close the dialog
                                onSelect(updatedChat)
                                onClose()
                              }}
                            >
                              {chat.title}
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <span className={cn("text-sm", theme === "light" ? "text-gray-600" : "text-gray-400")}>
                                Last message {formatTimestamp(chat.date)}
                              </span>
                              {chat.machines && chat.machines.length > 0 && (
                                <>
                                  <span className={theme === "light" ? "text-gray-400" : "text-gray-600"}>•</span>
                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className={cn("text-sm", theme === "light" ? "text-gray-600" : "text-gray-400")}
                                    >
                                      {chat.machines
                                        .slice(0, 2)
                                        .map((machine) => machine.name)
                                        .join(", ")}
                                      {chat.machines.length > 2 &&
                                        `, ${chat.machines.length - 2} other${chat.machines.length - 2 > 1 ? "s" : ""}`}
                                    </span>
                                  </div>
                                </>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
      <style jsx global>{`
  /* Hide default close button */
  .custom-close-button [data-radix-collection-item],
  .custom-close-button [data-dialog-close] {
    display: none !important;
  }
  
  /* Additional specificity for the default close button */
  .custom-close-button button[aria-label="Close"] {
    display: none !important;
  }
`}</style>
    </Dialog>
  )
}

