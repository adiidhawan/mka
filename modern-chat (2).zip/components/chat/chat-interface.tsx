"use client"

import { useState, useRef, useEffect, useMemo, useCallback } from "react"
import { FeedbackDialog } from "@/components/feedback-dialog"
import { useTheme } from "@/contexts/ThemeContext"
import { ErrorBoundary } from "@/components/shared/error-boundary"
import { MessageList } from "@/components/chat/message-list"
import { InputArea } from "@/components/chat/input-area"
import { ThemeToggle } from "@/components/shared/theme-toggle"
import { useAudioRecording } from "@/hooks/use-audio-recording"
import { getGreeting } from "@/utils/format"
import { ChatHeader } from "@/components/layout/chat-header"
import { cn } from "@/lib/utils"
import type { ChatItem, Message, Machine } from "@/types/chat"

interface ChatInterfaceProps {
  isSidebarPinned: boolean
  selectedChat: ChatItem | null
  onNewMessage: (message: string) => void
  handleReactionClick: (msgId: string, reactionType: string, isActive: boolean) => void
  handleFeedbackSubmit: (data: any) => void
  handleFeedbackCancel: () => void
  initialState?: boolean
  toggleStarChat: (chatId: string) => void
  createNewChat: () => void
  updateChatName: (chatId: string, newName: string) => void
  updateChatMachine: (chatId: string, machine: Machine | null) => void
  setIsInitialState: (value: boolean) => void
  machines: Machine[]
}

export default function ChatInterface({
  isSidebarPinned,
  selectedChat,
  onNewMessage,
  handleReactionClick: parentHandleReactionClick,
  handleFeedbackSubmit,
  handleFeedbackCancel,
  initialState = true,
  toggleStarChat,
  createNewChat,
  updateChatName,
  updateChatMachine,
  setIsInitialState,
  machines,
}: ChatInterfaceProps) {
  const { theme } = useTheme()
  const [activeReactions, setActiveReactions] = useState<Record<string, string>>({})
  const [pendingReactions, setPendingReactions] = useState<Record<string, string>>({})
  const [activeFeedback, setActiveFeedback] = useState<{ messageId: string; type: "good" | "great" | "bad" } | null>(
    null,
  )
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [isInitialState, _setIsInitialState] = useState(initialState)
  const [greeting, setGreeting] = useState("")

  const {
    isRecording,
    recordingTime,
    transcript,
    startRecording,
    stopRecording,
    cancelRecording,
    handleRecordingSubmit,
  } = useAudioRecording(setMessages)

  // Sync local state with prop
  useEffect(() => {
    _setIsInitialState(initialState)
  }, [initialState])

  // Sync messages with selectedChat
  useEffect(() => {
    if (selectedChat) {
      setMessages(selectedChat.messages)
    }
  }, [selectedChat])

  // Scroll to bottom when messages change
  useEffect(() => {
    const scrollToBottom = () => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
      }
    }

    const timeoutId = setTimeout(() => {
      scrollToBottom()
    }, 100)

    return () => clearTimeout(timeoutId)
  }, [messages])

  // Update greeting periodically
  useEffect(() => {
    setGreeting(getGreeting())
    const interval = setInterval(() => setGreeting(getGreeting()), 60000)
    return () => clearInterval(interval)
  }, [])

  // Handle reaction clicks locally before passing to parent
  const handleReactionClick = useCallback(
    (msgId: string, reactionType: string, isActive: boolean) => {
      if (isActive) {
        // Remove reaction if already active
        setActiveReactions((prev) => {
          const newState = { ...prev }
          delete newState[msgId]
          return newState
        })

        setPendingReactions((prev) => {
          const newState = { ...prev }
          delete newState[msgId]
          return newState
        })

        setActiveFeedback(null)
      } else {
        // Set pending reaction
        setPendingReactions((prev) => ({
          ...prev,
          [msgId]: reactionType,
        }))

        // Show feedback dialog
        const feedbackType = reactionType === "like" ? "good" : reactionType === "love" ? "great" : "bad"
        setActiveFeedback({
          messageId: msgId,
          type: feedbackType as "good" | "great" | "bad",
        })
      }

      // Call parent handler
      parentHandleReactionClick(msgId, reactionType, isActive)
    },
    [parentHandleReactionClick],
  )

  // Handle feedback submission
  const onFeedbackSubmit = useCallback(
    (data: any) => {
      // Call parent handler
      handleFeedbackSubmit(data)

      // Update local state
      if (activeFeedback) {
        setActiveReactions((prev) => ({
          ...prev,
          [activeFeedback.messageId]: pendingReactions[activeFeedback.messageId],
        }))

        setPendingReactions((prev) => {
          const newState = { ...prev }
          delete newState[activeFeedback.messageId]
          return newState
        })
      }

      setActiveFeedback(null)
    },
    [activeFeedback, pendingReactions, handleFeedbackSubmit],
  )

  // Handle feedback cancellation
  const onFeedbackCancel = useCallback(() => {
    // Call parent handler
    handleFeedbackCancel()

    // Update local state
    if (activeFeedback) {
      setPendingReactions((prev) => {
        const newState = { ...prev }
        delete newState[activeFeedback.messageId]
        return newState
      })
    }

    setActiveFeedback(null)
  }, [activeFeedback, handleFeedbackCancel])

  const handleSubmit = useCallback(
    async (message: string) => {
      if (!message.trim()) return

      // Update both local and parent state
      _setIsInitialState(false)
      setIsInitialState(false)
      setIsLoading(true)

      try {
        // Add user message to local state for immediate feedback
        const newUserMessage: Message = {
          id: Date.now().toString(),
          role: "user",
          content: message.trim(),
        }

        setMessages((prev) => [...prev, newUserMessage])

        // Send message to parent for processing
        onNewMessage(message)
      } catch (error) {
        console.error("Error submitting message:", error)
        setError("Failed to send message. Please try again.")
      } finally {
        setIsLoading(false)
      }
    },
    [onNewMessage, setIsInitialState],
  )

  const handleNewChatClick = useCallback(() => {
    createNewChat()
    _setIsInitialState(true)
    setIsInitialState(true)
  }, [createNewChat, setIsInitialState])

  const handleMachineChange = useCallback(
    (machine: Machine | null) => {
      if (selectedChat) {
        updateChatMachine(selectedChat.id, machine)
      }
    },
    [selectedChat, updateChatMachine],
  )

  // Memoize components to prevent unnecessary re-renders
  const memoizedMessageList = useMemo(
    () => (
      <MessageList
        messages={selectedChat?.messages || messages}
        activeReactions={activeReactions}
        pendingReactions={pendingReactions}
        handleReactionClick={handleReactionClick}
        theme={theme}
        isLoading={isLoading}
        selectedMachine={selectedChat?.machines?.[0] || null}
      />
    ),
    [
      selectedChat?.messages,
      messages,
      activeReactions,
      pendingReactions,
      handleReactionClick,
      theme,
      isLoading,
      selectedChat?.machines,
    ],
  )

  const memoizedInputArea = useMemo(
    () => (
      <InputArea
        isSidebarPinned={isSidebarPinned}
        selectedMachines={selectedChat?.machines || []}
        isRecording={isRecording}
        recordingTime={recordingTime}
        transcript={transcript}
        handleSubmit={handleSubmit}
        handleRecordingSubmit={handleRecordingSubmit}
        startRecording={startRecording}
        stopRecording={stopRecording}
        cancelRecording={cancelRecording}
        isInitialState={isInitialState}
        setIsInitialState={(value) => {
          _setIsInitialState(value)
          setIsInitialState(value)
        }}
        greeting={greeting}
      />
    ),
    [
      isSidebarPinned,
      selectedChat?.machines,
      isRecording,
      recordingTime,
      transcript,
      handleSubmit,
      handleRecordingSubmit,
      startRecording,
      stopRecording,
      cancelRecording,
      isInitialState,
      setIsInitialState,
      greeting,
    ],
  )

  const memoizedChatHeader = useMemo(
    () => (
      <ChatHeader
        className={isSidebarPinned ? "left-80" : "left-0"}
        selectedMachines={selectedChat?.machines || []}
        onMachineChange={handleMachineChange}
        chat={selectedChat}
        onToggleStar={toggleStarChat}
        onNewChat={handleNewChatClick}
        onRename={updateChatName}
        isInitialState={isInitialState}
        isActive={!isInitialState}
      />
    ),
    [
      isSidebarPinned,
      selectedChat,
      handleMachineChange,
      toggleStarChat,
      handleNewChatClick,
      updateChatName,
      isInitialState,
    ],
  )

  return (
    <ErrorBoundary>
      <div className="relative flex h-[calc(100vh-43px)] flex-col">
        {error && (
          <div className="absolute top-0 left-0 right-0 bg-red-500 text-white p-2 text-center z-50">{error}</div>
        )}

        {memoizedChatHeader}

        {isInitialState ? (
          <div className="flex items-center justify-center h-full">
            <div className="w-full max-w-3xl px-4">
              <h1 className="text-4xl font-semibold text-center mb-8 relative z-10">
                <span
                  className={cn(
                    "bg-clip-text text-transparent animate-gradient-x-enhanced outer-glow",
                    theme === "light"
                      ? "bg-gradient-to-r from-purple-400 via-black to-purple-400"
                      : "bg-gradient-to-r from-purple-400 via-white to-purple-400",
                  )}
                >
                  {greeting}
                </span>
              </h1>
              {memoizedInputArea}
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto pt-14 pb-[120px] custom-scrollbar">
              <div className={cn("mx-auto max-w-3xl px-4 pb-36", isSidebarPinned ? "ml-2" : "")}>
                {memoizedMessageList}
                <div ref={messagesEndRef} />
              </div>
            </div>
            {memoizedInputArea}
          </>
        )}

        <ThemeToggle />

        {activeFeedback && (
          <FeedbackDialog type={activeFeedback.type} onClose={onFeedbackCancel} onSubmit={onFeedbackSubmit} />
        )}
      </div>
    </ErrorBoundary>
  )
}

