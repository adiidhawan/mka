"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"

export const WaveformVisualization: React.FC<{ small?: boolean }> = ({ small = false }) => {
  const [audioLevels, setAudioLevels] = useState<number[]>(Array(small ? 10 : 20).fill(0))
  const audioContextRef = useRef<AudioContext | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const dataArrayRef = useRef<Uint8Array | null>(null)
  const animationFrameIdRef = useRef<number | null>(null)
  const streamRef = useRef<MediaStream | null>(null)

  useEffect(() => {
    let isMounted = true

    const initAudio = async () => {
      try {
        // Get user media
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        })

        // Store stream reference for cleanup
        streamRef.current = stream

        // Create audio context
        const audioContext = new AudioContext()
        audioContextRef.current = audioContext

        // Create analyzer
        const analyser = audioContext.createAnalyser()
        analyserRef.current = analyser

        // Connect source
        const source = audioContext.createMediaStreamSource(stream)
        source.connect(analyser)

        // Configure analyzer
        analyser.fftSize = 64
        const bufferLength = analyser.frequencyBinCount
        dataArrayRef.current = new Uint8Array(bufferLength)

        // Update levels function with animation frame
        const updateLevels = () => {
          if (!isMounted) return

          if (analyserRef.current && dataArrayRef.current) {
            analyserRef.current.getByteFrequencyData(dataArrayRef.current)

            // Only update state if component is still mounted
            if (isMounted) {
              const levels = Array.from(dataArrayRef.current.slice(0, small ? 10 : 20)).map((value) => value / 255)
              setAudioLevels(levels)
            }
          }

          // Store animation frame ID for cleanup
          if (isMounted) {
            animationFrameIdRef.current = requestAnimationFrame(updateLevels)
          }
        }

        // Start animation
        updateLevels()
      } catch (error) {
        console.error("Error accessing microphone:", error)
      }
    }

    initAudio()

    // Cleanup function
    return () => {
      isMounted = false

      // Cancel animation frame
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current)
        animationFrameIdRef.current = null
      }

      // Close audio context
      if (audioContextRef.current) {
        audioContextRef.current.close()
        audioContextRef.current = null
      }

      // Stop all tracks
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }
    }
  }, [small])

  return (
    <div className={`flex items-center justify-center ${small ? "h-6 w-20 mx-2" : "w-full h-full"}`}>
      {audioLevels.map((level, index) => (
        <div
          key={index}
          className={`${small ? "w-0.5 mx-px" : "w-1 mx-px"} h-full flex items-center justify-center group`}
        >
          <div
            className="w-full bg-gradient-to-b from-red-500 to-red-700 rounded-full transition-all duration-100 ease-in-out group-hover:from-red-400 group-hover:to-red-600"
            style={{
              height: `${Math.max(small ? 3 : 5, level * 100)}%`, // Ensure minimum height for better visualization
              transform: `scaleY(${0.3 + level * 0.7})`,
            }}
          />
        </div>
      ))}
    </div>
  )
}

