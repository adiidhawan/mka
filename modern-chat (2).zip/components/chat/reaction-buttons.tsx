"use client"

import type React from "react"
import { useState } from "react"
import { Copy, Volume2 } from "lucide-react"
import { cn } from "@/lib/utils"
import type { ReactionState, Machine } from "@/types/chat"
import { apiService, fallbackTTS } from "@/lib/api"

interface ReactionButtonsProps {
  msgId: string
  content: string
  activeReactions: ReactionState
  pendingReactions?: ReactionState
  handleReactionClick: (msgId: string, reactionType: string, isActive: boolean) => void
  theme: string
  messageMachine?: Machine | null
}

// Custom SVG icons that completely fill when active and are filled with grey by default
const ThumbsUpIcon = ({ isActive }: { isActive: boolean }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill={isActive ? "currentColor" : "#9CA3AF"} // Default fill is grey
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M7 10v12" />
    <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
  </svg>
)

const ThumbsDownIcon = ({ isActive }: { isActive: boolean }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill={isActive ? "currentColor" : "#9CA3AF"} // Default fill is grey
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M17 14V2" />
    <path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z" />
  </svg>
)

// Custom DoubleThumbsUp component
const DoubleThumbsUpIcon = ({ isActive }: { isActive: boolean }) => (
  <div className="relative w-4 h-3.5 flex items-center">
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill={isActive ? "#93C5FD" : "#9CA3AF"} // Default fill is grey, active is light blue
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={isActive ? "text-blue-300 absolute left-0" : "absolute left-0"}
    >
      <path d="M7 10v12" />
      <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
    </svg>
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill={isActive ? "#1D4ED8" : "#6B7280"} // Default fill is darker grey, active is dark blue
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={isActive ? "text-blue-700 absolute left-1.5" : "absolute left-1.5"}
    >
      <path d="M7 10v12" />
      <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
    </svg>
  </div>
)

export const ReactionButtons: React.FC<ReactionButtonsProps> = ({
  msgId,
  content,
  activeReactions,
  pendingReactions = {},
  handleReactionClick,
  theme,
  messageMachine,
}) => {
  const [copied, setCopied] = useState(false)
  const [isAudioLoading, setIsAudioLoading] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Direct implementation of text-to-speech using the API service
  const handleAudioClick = async () => {
    if (!content) return

    setIsAudioLoading(true)
    try {
      // Use the API service directly to convert text to speech
      const result = await apiService.textToSpeech(content, "en")

      if (result.success) {
        if (!result.fallback) {
          // If API call was successful, play the audio
          const audio = new Audio(`data:audio/mp3;base64,${result.data.audio}`)
          audio.play()
        }
        // If fallback was used, the browser's speech synthesis was already triggered
      } else {
        // If API call failed, use browser's native speech synthesis as fallback
        await fallbackTTS(content)
      }
    } catch (error) {
      console.error("Text-to-speech error:", error)
      // Use browser's native speech synthesis as fallback
      try {
        await fallbackTTS(content)
      } catch (fallbackError) {
        console.error("Fallback TTS error:", fallbackError)
      }
    } finally {
      setTimeout(() => {
        setIsAudioLoading(false)
      }, 1000)
    }
  }

  const isActive = (type: string) => activeReactions[msgId] === type

  // Define reactions with darker active colors
  const reactions = [
    {
      icon: ThumbsUpIcon,
      label: "Good response",
      key: "like",
      activeColor: "text-green-700", // Darker green
      inactiveColor: theme === "light" ? "text-gray-600" : "text-gray-400",
    },
    {
      icon: DoubleThumbsUpIcon,
      label: "Great response",
      key: "love",
      activeColor: "text-blue-700", // Darker blue
      inactiveColor: theme === "light" ? "text-gray-600" : "text-gray-400",
    },
    {
      icon: ThumbsDownIcon,
      label: "Bad response",
      key: "dislike",
      activeColor: "text-red-700", // Darker red
      inactiveColor: theme === "light" ? "text-gray-600" : "text-gray-400",
    },
  ]

  return (
    <div className="flex items-center gap-2 mt-1 ml-10">
      {/* Reaction buttons */}
      {reactions.map((reaction) => {
        const isActiveReaction = isActive(reaction.key)

        return (
          <div key={reaction.key} className="group relative">
            <button
              onClick={() => handleReactionClick(msgId, reaction.key, isActiveReaction)}
              className={cn(
                "p-1.5 rounded-full transition-all duration-400 ease-in-out hover:scale-110 focus:outline-none",
                isActiveReaction ? reaction.activeColor : reaction.inactiveColor,
              )}
            >
              <reaction.icon isActive={isActiveReaction} />
            </button>
            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white z-10">
              {reaction.label}
              {isActiveReaction && " (active)"}
            </div>
          </div>
        )
      })}

      {/* Audio button */}
      <div className="group relative">
        <button
          onClick={handleAudioClick}
          disabled={isAudioLoading}
          className={cn(
            "p-[7px] rounded-full transition-all duration-300 hover:scale-110 focus:outline-none",
            isAudioLoading ? "text-blue-600" : "text-blue-500 dark:text-blue-400",
            isAudioLoading && "opacity-70 cursor-wait",
          )}
        >
          {isAudioLoading ? (
            <div
              className="w-[19px] h-[19px] animate-spin rounded-full border-2 border-t-transparent"
              style={{ borderColor: "currentColor transparent currentColor currentColor" }}
            />
          ) : (
            <Volume2 className="w-[17px] h-[17px]" strokeWidth={1.75} fill={isAudioLoading ? "currentColor" : "none"} />
          )}
        </button>
        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white z-10">
          {isAudioLoading ? "Processing..." : "Audio feedback"}
        </div>
      </div>

      {/* Copy button */}
      <div className="group relative">
        <button
          onClick={handleCopy}
          className={cn(
            "p-1.5 rounded-full transition-all duration-300 hover:scale-110 focus:outline-none",
            copied ? "text-yellow-600" : "text-yellow-500 dark:text-yellow-400",
          )}
        >
          <Copy className="w-3.5 h-3.5" strokeWidth={1.75} fill={copied ? "currentColor" : "none"} />
        </button>
        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white z-10">
          {copied ? "Copied!" : "Copy"}
        </div>
      </div>

      {/* Machine info */}
      {messageMachine && (
        <div className="ml-auto text-xs text-gray-500 dark:text-gray-400 italic">
          Response Generated for: {messageMachine.name}
        </div>
      )}
    </div>
  )
}

