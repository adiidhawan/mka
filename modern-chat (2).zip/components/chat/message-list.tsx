"use client"

import React, { useMemo } from "react"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { VoiceMessagePlayer } from "@/components/chat/voice-message-player"
import { ReactionButtons } from "@/components/chat/reaction-buttons"
import type { Message, ReactionState } from "@/types/chat"
import type { Machine } from "@/types/chat"

// Extracted message component for better memoization
const MessageItem = React.memo(
  ({
    msg,
    index,
    isLastMessage,
    isLoading,
    theme,
    activeReactions,
    pendingReactions,
    handleReactionClick,
    selectedMachine,
  }: {
    msg: Message
    index: number
    isLastMessage: boolean
    isLoading: boolean
    theme: string
    activeReactions: ReactionState
    pendingReactions: ReactionState
    handleReactionClick: (msgId: string, reactionType: string, isActive: boolean) => void
    selectedMachine: Machine | null
  }) => {
    // Skip rendering the initial message
    if (msg.isInitial) return null

    const isUser = msg.role === "user"
    const isAssistant = msg.role === "assistant"

    // Determine message background color based on reactions
    const getMessageBackground = () => {
      if (isUser) return "bg-[#E6F3FF] dark:bg-[#281E5D] text-black dark:text-white"

      if (msg.isInitial) {
        return "from-purple-300 to-purple-500 dark:from-purple-700 dark:to-purple-900 shadow-[0_0_15px_rgba(147,51,234,0.5)]"
      }

      if (activeReactions[msg.id] === "like") {
        return "from-green-300 to-green-500 dark:from-green-700 dark:to-green-900 shadow-[0_0_15px_rgba(34,197,94,0.5)]"
      }

      if (activeReactions[msg.id] === "love") {
        return "from-blue-300 to-blue-500 dark:from-blue-700 dark:to-blue-900 shadow-[0_0_15px_rgba(59,130,246,0.5)]"
      }

      if (activeReactions[msg.id] === "dislike") {
        return "from-red-300 to-red-500 dark:from-red-700 dark:to-red-900 shadow-[0_0_15px_rgba(220,38,38,0.5)]"
      }

      return "bg-[#F0F0F0] dark:bg-[#333333]/95"
    }

    const messageContent = typeof msg.content === "string" ? msg.content : JSON.stringify(msg.content)

    return (
      <div className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}>
        <div className={`flex ${isUser ? "flex-row-reverse items-end" : "flex-row items-start"} w-full gap-2`}>
          {isUser && (
            <Avatar className="h-6 w-6 bg-white dark:bg-[#1A1D21]">
              <AvatarFallback className="text-xs font-medium text-black dark:text-white">
                {msg.avatar || "A"}
              </AvatarFallback>
            </Avatar>
          )}
          {isAssistant && !msg.isInitial && (
            <Avatar className="h-6 w-6 bg-white dark:bg-[#1A1D21]">
              <AvatarFallback className="text-xs font-medium text-black dark:text-white">
                <img
                  src={
                    theme === "dark"
                      ? "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mkalight%202.jpg-HLqrjkKmw3RzSf7SBIuixlJZWgQUF4.jpeg"
                      : "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mkalight.jpg-C0ekbWl4x3MzvKk1mrcXgyfLgHvnGw.jpeg"
                  }
                  alt="Maintenance Mitra"
                  className="w-full h-full object-cover rounded-full"
                  loading="lazy"
                />
              </AvatarFallback>
            </Avatar>
          )}
          <div className={`max-w-[80%] ${isUser ? "mr-2" : "ml-2"}`}>
            <div
              className={cn(
                "relative rounded-[20px] min-h-[44px] text-[15px] leading-relaxed backdrop-blur-sm",
                isUser
                  ? "bg-[#E6F3FF] dark:bg-[#281E5D] text-black dark:text-white"
                  : cn(
                      "bg-gradient-to-br text-black dark:text-white transition-all duration-300",
                      getMessageBackground(),
                    ),
              )}
            >
              <div className={cn("py-3 px-4", msg.audioUrl && "!p-0")}>
                {msg.audioUrl ? <VoiceMessagePlayer audioUrl={msg.audioUrl} /> : <>{messageContent}</>}
              </div>
              {isLoading && isAssistant && isLastMessage && (
                <div className="absolute bottom-0 left-0 right-0 flex justify-center items-center h-8">
                  <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              )}
            </div>
          </div>
        </div>
        {isAssistant && !msg.isInitial && (
          <ReactionButtons
            msgId={msg.id}
            content={messageContent}
            activeReactions={activeReactions}
            pendingReactions={pendingReactions}
            handleReactionClick={handleReactionClick}
            theme={theme}
            messageMachine={msg.machine || null}
          />
        )}
      </div>
    )
  },
)

MessageItem.displayName = "MessageItem"

// Initial message component extracted for better memoization
const InitialMessage = React.memo(({ theme }: { theme: string }) => (
  <div className="flex flex-col items-start">
    <div className="flex flex-row items-start w-full gap-2">
      <div className="max-w-[80%] ml-2">
        <div
          className={cn(
            "relative rounded-[20px] min-h-[44px] text-[15px] leading-relaxed backdrop-blur-sm",
            theme === "light" ? "bg-blue-200 text-blue-800" : "bg-[#322277] text-white",
            "transition-all duration-500 ease-in-out",
          )}
        >
          <div className={cn("py-3 px-4")}>Hi, I am Maintenance Mitra. How may I help you today?</div>
        </div>
      </div>
    </div>
  </div>
))

InitialMessage.displayName = "InitialMessage"

interface MessageListProps {
  messages: Message[]
  activeReactions: ReactionState
  pendingReactions: ReactionState
  handleReactionClick: (msgId: string, reactionType: string, isActive: boolean) => void
  theme: string
  isLoading: boolean
  selectedMachine: Machine | null
}

export const MessageList: React.FC<MessageListProps> = React.memo(
  ({ messages, activeReactions, pendingReactions, handleReactionClick, theme, isLoading, selectedMachine }) => {
    // Find the initial message - memoized to avoid recalculation
    const initialMessage = useMemo(() => messages.find((msg) => msg.isInitial), [messages])

    // Memoize the filtered messages to avoid unnecessary re-renders
    const filteredMessages = useMemo(() => messages.filter((msg) => !msg.isInitial), [messages])

    return (
      <div className="space-y-6 pt-4">
        {/* Always render the initial message */}
        {initialMessage && <InitialMessage theme={theme} />}

        {/* Render the rest of the messages */}
        {filteredMessages.map((msg, index) => (
          <MessageItem
            key={msg.id || index}
            msg={msg}
            index={index}
            isLastMessage={index === filteredMessages.length - 1}
            isLoading={isLoading}
            theme={theme}
            activeReactions={activeReactions}
            pendingReactions={pendingReactions}
            handleReactionClick={handleReactionClick}
            selectedMachine={selectedMachine}
          />
        ))}
      </div>
    )
  },
)

MessageList.displayName = "MessageList"

