"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useTheme } from "@/contexts/ThemeContext"
import { cn } from "@/lib/utils"
import { getGreeting } from "@/utils/get-greeting"
import { Button } from "@/components/ui/button"
import { Search, MessageSquare, Mic, Send } from "lucide-react"

interface CenteredChatInputProps {
  onSubmit: (message: string) => void
  isLoading?: boolean
  userName?: string
  className?: string
}

export function CenteredChatInput({
  onSubmit,
  isLoading = false,
  userName = "User",
  className,
}: CenteredChatInputProps) {
  const [message, setMessage] = useState("")
  const [greeting, setGreeting] = useState("")
  const [isCentered, setIsCentered] = useState(true)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const { theme } = useTheme()

  useEffect(() => {
    setGreeting(getGreeting(userName))
    const interval = setInterval(() => {
      setGreeting(getGreeting(userName))
    }, 60000)

    return () => clearInterval(interval)
  }, [userName])

  useEffect(() => {
    const textarea = textareaRef.current
    if (!textarea) return

    const adjustHeight = () => {
      textarea.style.height = "inherit"
      textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`
    }

    textarea.addEventListener("input", adjustHeight)
    return () => textarea.removeEventListener("input", adjustHeight)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (message.trim() && !isLoading) {
      onSubmit(message.trim())
      setMessage("")
      if (textareaRef.current) {
        textareaRef.current.style.height = "inherit"
      }
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  const handleFocus = () => {
    setIsCentered(false)
  }

  return (
    <div
      className={cn(
        "w-full max-w-4xl mx-auto px-4 transition-all duration-500 ease-in-out",
        isCentered ? "mb-0 h-screen flex items-center justify-center" : "mb-8",
      )}
    >
      <div
        className={cn("flex flex-col items-center justify-center", isCentered ? "w-full" : "w-full max-w-2xl mx-auto")}
      >
        {isCentered && <h1 className="text-4xl font-semibold mb-8 text-center">What can I help with?</h1>}
        <form
          onSubmit={handleSubmit}
          className={cn(
            "w-full relative rounded-2xl shadow-lg transition-all duration-300",
            theme === "light" ? "bg-white border border-gray-200" : "bg-[#1a2942]/90 border border-gray-700",
            className,
          )}
        >
          <div className="flex items-center p-4">
            <div className="flex-1 min-w-0">
              <textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                onFocus={handleFocus}
                placeholder={isCentered ? greeting : "Ask anything..."}
                rows={1}
                className={cn(
                  "w-full resize-none bg-transparent border-0 outline-none text-base",
                  "placeholder:text-gray-500",
                  theme === "light" ? "text-gray-900" : "text-gray-100",
                )}
                style={{ maxHeight: "200px" }}
              />
            </div>
            <div className="flex items-center gap-2 ml-4">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <Search className="h-5 w-5" />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <MessageSquare className="h-5 w-5" />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <Mic className="h-5 w-5" />
              </Button>
              <Button
                type="submit"
                variant="ghost"
                size="icon"
                disabled={!message.trim() || isLoading}
                className={cn(
                  "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200",
                  message.trim() && "text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300",
                )}
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

