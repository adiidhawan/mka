"use client"

import React, { useMemo } from "react"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { VoiceMessagePlayer } from "@/components/voice-message-player"
import { ReactionButtons } from "@/components/reaction-buttons"

// Extracted message component for better memoization
const MessageItem = React.memo(
  ({
    msg,
    index,
    isLastMessage,
    isLoading,
    theme,
    activeReactions,
    pendingReactions,
    handleReactionClick,
    playTextToSpeech,
    selectedMachine,
  }) => {
    // Skip rendering the initial message
    if (msg.isInitial) return null

    const isUser = msg.role === "user"
    const isAssistant = msg.role === "assistant"
    const isMessageLoading = msg.isLoading === true
    const isMessageError = msg.isError === true

    // Determine message background color based on reactions and states
    const getMessageBackground = () => {
      if (isUser) return "bg-[#E6F3FF] dark:bg-[#281E5D] text-black dark:text-white"

      if (msg.isInitial) {
        return "from-purple-300 to-purple-500 dark:from-purple-700 dark:to-purple-900 shadow-[0_0_15px_rgba(147,51,234,0.5)]"
      }

      if (isMessageError) {
        return "from-red-300 to-red-500 dark:from-red-700 dark:to-red-900 shadow-[0_0_15px_rgba(220,38,38,0.5)]"
      }

      if (activeReactions[msg.id] === "like") {
        return "from-green-300 to-green-500 dark:from-green-700 dark:to-green-900 shadow-[0_0_15px_rgba(34,197,94,0.5)]"
      }

      if (activeReactions[msg.id] === "love") {
        return "from-blue-300 to-blue-500 dark:from-blue-700 dark:to-blue-900 shadow-[0_0_15px_rgba(59,130,246,0.5)]"
      }

      if (activeReactions[msg.id] === "dislike") {
        return "from-red-300 to-red-500 dark:from-red-700 dark:to-red-900 shadow-[0_0_15px_rgba(220,38,38,0.5)]"
      }

      return "bg-[#F0F0F0] dark:bg-[#333333]/95"
    }

    const messageContent = typeof msg.content === "string" ? msg.content : JSON.stringify(msg.content)

    return (
      <div className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}>
        <div className={`flex ${isUser ? "flex-row-reverse items-end" : "flex-row items-start"} w-full gap-2`}>
          {isUser && (
            <Avatar className="h-6 w-6 bg-white dark:bg-[#1A1D21]">
              <AvatarFallback className="text-xs font-medium text-black dark:text-white">
                {msg.avatar || "A"}
              </AvatarFallback>
            </Avatar>
          )}
          {isAssistant && !msg.isInitial && (
            <Avatar className="h-6 w-6 bg-white dark:bg-[#1A1D21]">
              <AvatarFallback className="text-xs font-medium text-black dark:text-white">
                <img
                  src={
                    theme === "dark"
                      ? "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mkalight%202.jpg-HLqrjkKmw3RzSf7SBIuixlJZWgQUF4.jpeg"
                      : "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mkalight.jpg-C0ekbWl4x3MzvKk1mrcXgyfLgHvnGw.jpeg"
                  }
                  alt="Maintenance Mitra"
                  className="w-full h-full object-cover rounded-full"
                  loading="lazy"
                />
              </AvatarFallback>
            </Avatar>
          )}
          <div className={`max-w-[80%] ${isUser ? "mr-2" : "ml-2"}`}>
            <div
              className={cn(
                "relative rounded-[20px] min-h-[44px] text-[15px] leading-relaxed backdrop-blur-sm",
                isUser
                  ? "bg-[#E6F3FF] dark:bg-[#281E5D] text-black dark:text-white"
                  : cn(
                      "bg-gradient-to-br text-black dark:text-white transition-all duration-300",
                      getMessageBackground(),
                    ),
              )}
            >
              <div className={cn("py-3 px-4", msg.audioUrl && "!p-0")}>
                {msg.audioUrl ? (
                  <VoiceMessagePlayer audioUrl={msg.audioUrl} />
                ) : isMessageLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-pulse flex space-x-2">
                      <div className="h-2 w-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="h-2 w-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-bounce delay-75"></div>
                      <div className="h-2 w-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-bounce delay-150"></div>
                    </div>
                  </div>
                ) : (
                  <div className="formatted-content">
                    {messageContent.includes("**") ||
                    /\d+\.\s/.test(messageContent) ||
                    messageContent.includes("Document Name:") ? (
                      <div className="space-y-2">
                        {messageContent.split("\n\n").map((paragraph, i) => {
                          // Handle document/reference headers
                          if (
                            paragraph.includes("Document Name:") ||
                            paragraph.includes("**Document") ||
                            paragraph.includes("**Reference:")
                          ) {
                            return (
                              <div
                                key={i}
                                className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md mb-4 border-l-4 border-blue-500"
                              >
                                <p className="font-semibold">{paragraph.replace(/\*\*/g, "")}</p>
                              </div>
                            )
                          }

                          // Handle numbered list items with bold headers
                          if (/^\d+\.\s+\*\*/.test(paragraph)) {
                            const match = paragraph.match(/^(\d+\.\s+)(\*\*[^*]+\*\*:?)(.*)$/)
                            if (match) {
                              const [_, number, header, content] = match
                              return (
                                <div key={i} className="flex mb-4 group">
                                  <div className="font-bold mr-2 text-blue-600 dark:text-blue-400 min-w-[28px]">
                                    {number}
                                  </div>
                                  <div className="flex-1">
                                    <span className="font-semibold">{header.replace(/\*\*/g, "")}</span>
                                    {content}
                                  </div>
                                </div>
                              )
                            }
                          }

                          // Handle regular numbered list items
                          if (/^\d+\.\s+/.test(paragraph)) {
                            const match = paragraph.match(/^(\d+\.\s+)(.*)$/)
                            if (match) {
                              const [_, number, content] = match
                              return (
                                <div key={i} className="flex mb-4">
                                  <div className="font-bold mr-2 text-blue-600 dark:text-blue-400 min-w-[28px]">
                                    {number}
                                  </div>
                                  <div className="flex-1">{content}</div>
                                </div>
                              )
                            }
                          }

                          // Handle paragraphs with bold text (potential headers)
                          if (paragraph.startsWith("**") && paragraph.includes("**:")) {
                            const parts = paragraph.split(/(\*\*[^*]+\*\*:)/)
                            return (
                              <div key={i} className="mb-3">
                                {parts.map((part, j) => {
                                  if (part.startsWith("**") && part.endsWith("**:")) {
                                    return (
                                      <h3 key={j} className="font-semibold text-lg mb-2">
                                        {part.replace(/\*\*|:/g, "")}
                                      </h3>
                                    )
                                  }
                                  return part && <p key={j}>{part}</p>
                                })}
                              </div>
                            )
                          }

                          // Handle paragraphs with bold text sections
                          if (paragraph.includes("**")) {
                            return (
                              <p key={i} className="mb-3">
                                {paragraph.split(/(\*\*[^*]+\*\*)/).map((part, j) => {
                                  if (part.startsWith("**") && part.endsWith("**")) {
                                    return (
                                      <strong key={j} className="font-semibold">
                                        {part.replace(/\*\*/g, "")}
                                      </strong>
                                    )
                                  }
                                  return <span key={j}>{part}</span>
                                })}
                              </p>
                            )
                          }

                          // Regular paragraphs
                          return (
                            paragraph.trim() && (
                              <p key={i} className="mb-3">
                                {paragraph}
                              </p>
                            )
                          )
                        })}
                      </div>
                    ) : (
                      <>{messageContent}</>
                    )}
                  </div>
                )}
              </div>
              {isLoading && isAssistant && isLastMessage && !isMessageLoading && (
                <div className="absolute bottom-0 left-0 right-0 flex justify-center items-center h-8">
                  <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              )}
            </div>
          </div>
        </div>
        {isAssistant && !msg.isInitial && !isMessageLoading && !isMessageError && (
          <ReactionButtons
            msgId={msg.id}
            content={messageContent}
            activeReactions={activeReactions}
            pendingReactions={pendingReactions}
            handleReactionClick={handleReactionClick}
            theme={theme}
            playTextToSpeech={playTextToSpeech}
            selectedMachine={selectedMachine}
          />
        )}
      </div>
    )
  },
)

MessageItem.displayName = "MessageItem"

// Initial message component extracted for better memoization
const InitialMessage = React.memo(({ theme }) => (
  <div className="flex flex-col items-start">
    <div className="flex flex-row items-start w-full gap-2">
      <div className="max-w-[80%] ml-2">
        <div
          className={cn(
            "relative rounded-[20px] min-h-[44px] text-[15px] leading-relaxed backdrop-blur-sm",
            "bg-gradient-to-br text-black dark:text-white transition-all duration-500 ease-in-out",
            "from-purple-300 to-purple-500 dark:from-purple-700 dark:to-purple-900 shadow-[0_0_15px_rgba(147,51,234,0.5)]",
          )}
        >
          <div className={cn("py-3 px-4", theme === "light" ? "text-black" : "text-purple-300")}>
            Hi, I am Maintenance Mitra. How may I help you today?
          </div>
        </div>
      </div>
    </div>
  </div>
))

InitialMessage.displayName = "InitialMessage"

export const MessageList = React.memo(
  ({
    messages,
    activeReactions,
    pendingReactions,
    temporaryActions,
    handleReactionClick,
    theme,
    playTextToSpeech,
    isLoading,
    selectedMachine,
  }) => {
    // Find the initial message - memoized to avoid recalculation
    const initialMessage = useMemo(() => messages.find((msg) => msg.isInitial), [messages])

    // Memoize the filtered messages to avoid unnecessary re-renders
    const filteredMessages = useMemo(() => messages.filter((msg) => !msg.isInitial), [messages])

    return (
      <div className="space-y-6 pt-4">
        {/* Always render the initial message */}
        {initialMessage && <InitialMessage theme={theme} />}

        {/* Render the rest of the messages */}
        {filteredMessages.map((msg, index) => (
          <MessageItem
            key={msg.id || index}
            msg={msg}
            index={index}
            isLastMessage={index === filteredMessages.length - 1}
            isLoading={isLoading}
            theme={theme}
            activeReactions={activeReactions}
            pendingReactions={pendingReactions}
            handleReactionClick={handleReactionClick}
            playTextToSpeech={playTextToSpeech}
            selectedMachine={selectedMachine}
          />
        ))}
      </div>
    )
  },
)

MessageList.displayName = "MessageList"

