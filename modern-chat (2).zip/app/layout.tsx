import type React from "react"
import type { Metadata } from "next"
import { ThemeProvider } from "@/contexts/ThemeContext"
import { StaticBackground } from "@/components/shared/static-background"
import "@/app/globals.css"

export const metadata: Metadata = {
  title: "Maintenance Mitra",
  description: "AI-powered maintenance assistant for industrial equipment",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          <StaticBackground />
          <div className="relative z-10">{children}</div>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'