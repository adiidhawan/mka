import { StreamingTextResponse } from "ai"
import axios from "axios"

const API_BASE_URL = "https://tml-az-dev-pvevops-mka-be-app.azurewebsites.net"

// Create a custom axios instance with longer timeout for this endpoint
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000, // 60 seconds timeout
  headers: {
    "Content-Type": "application/json",
  },
})

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Validate input
    if (!messages || !Array.isArray(messages)) {
      return new Response(JSON.stringify({ error: "Invalid messages format" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    // Get the last user message
    const lastUserMessage = messages.filter((msg) => msg.role === "user").pop()

    if (!lastUserMessage) {
      return new Response(JSON.stringify({ error: "No user message found" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    // Extract machine name if available in the message metadata
    const machineName = lastUserMessage.machine?.name || ""

    // Create a readable stream
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Call your custom API endpoint with retry logic
          let response
          const retries = 2
          let attempt = 0

          while (attempt <= retries) {
            try {
              response = await apiClient.post("/query", {
                query: lastUserMessage.content,
                machine_name: machineName,
              })
              break // Success, exit the loop
            } catch (error) {
              attempt++
              console.warn(`API query attempt ${attempt}/${retries + 1} failed:`, error)

              if (attempt > retries) {
                throw error // Rethrow if we've exhausted all retries
              }

              // Wait before retrying (exponential backoff)
              await new Promise((resolve) => setTimeout(resolve, 1000 * Math.pow(2, attempt - 1)))
            }
          }

          // Get the response text
          const responseText = response?.data?.response || "Sorry, I couldn't generate a response."

          // Format the response with proper structure
          let formattedResponse = responseText

          // Check if it contains structured content that needs formatting
          if (
            responseText.includes("**") ||
            /\d+\.\s/.test(responseText) ||
            responseText.includes("Document Name:") ||
            responseText.includes("Reference:")
          ) {
            // First, handle document headers and metadata
            if (responseText.includes("**Document") || responseText.includes("Document Name:")) {
              // Ensure document headers are properly formatted
              formattedResponse = formattedResponse
                .replace(/(\*\*Document[^*]+\*\*)/g, "\n\n$1\n\n")
                .replace(/(Document Name:[^\n]+)/g, "\n\n$1\n\n")
            }

            // Handle numbered lists with proper formatting
            formattedResponse = formattedResponse
              // Format numbered items with bold headers
              .replace(/(\d+\.\s+)(\*\*[^*]+\*\*:?)/g, "\n\n$1$2\n")
              // Format regular numbered items
              .replace(/(\d+\.\s+)([^\n]+)/g, "\n\n$1$2\n")
              // Add spacing after page references
              .replace(/($$Page \d+$$\.)(\s+)/g, "$1\n\n")
              // Add spacing between sections
              .replace(/(\.\s+)(\d+\.\s+)/g, ".\n\n$2")
              // Format bold headers
              .replace(/(\*\*[^*]+\*\*)(:)/g, "$1$2\n")
              // Format bold text with dash
              .replace(/(\*\*[^*]+\*\*)\s+-\s+/g, "$1: ")

            // Clean up excessive newlines
            formattedResponse = formattedResponse.replace(/\n{3,}/g, "\n\n").trim()

            // Ensure proper spacing around headings
            formattedResponse = formattedResponse.replace(/(\n\n\*\*[^*]+\*\*\n)/g, "\n\n$1\n")
          }

          // Encode and send the response
          controller.enqueue(encoder.encode(formattedResponse))
          controller.close()
        } catch (error) {
          console.error("Error calling API:", error)
          controller.enqueue(
            encoder.encode(
              "Sorry, there was an error processing your request. The server might be busy, please try again later.",
            ),
          )
          controller.close()
        }
      },
    })

    // Return streaming response
    return new StreamingTextResponse(stream)
  } catch (error) {
    console.error("Chat API error:", error)
    return new Response(JSON.stringify({ error: "Failed to generate response" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

