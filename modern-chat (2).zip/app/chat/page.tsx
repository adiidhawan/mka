"use client"

import { useState, useCallback } from "react"
import ChatInterface from "@/components/chat/chat-interface"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { useTheme } from "@/contexts/ThemeContext"
import { useChat } from "@/hooks/use-chat"
import type { ChatItem, Machine } from "@/types/chat"
// import { BackgroundPattern } from "@/components/shared/background-pattern"

// Define available machines
const MACHINES: Machine[] = [
  { id: "Conveyor", name: "Conveyor" },
  { id: "ED Oven", name: "ED Oven" },
  { id: "Paint Robot", name: "Paint Robot" },
  { id: "Sealer Oven", name: "Sealer Oven" },
  { id: "Topcoat Oven", name: "Topcoat Oven" },
  { id: "Wax Robot", name: "Wax Robot" },
]

export default function ChatPage() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const { theme } = useTheme()

  const {
    chats,
    activeChat,
    setActiveChat,
    createNewChat,
    updateChatName,
    handleSubmit,
    handleReactionClick,
    handleFeedbackSubmit,
    handleFeedbackCancel,
    toggleStarChat,
    deleteChat,
    isInitialState,
    setIsInitialState,
    updateChatMachine,
  } = useChat()

  // Handle new message submission
  const handleNewMessage = useCallback(
    (message: string) => {
      handleSubmit(message, activeChat?.machines?.[0] || null)
    },
    [handleSubmit, activeChat],
  )

  // Handle chat selection
  const handleChatSelect = useCallback(
    (chat: ChatItem) => {
      setActiveChat(chat)
      setIsInitialState(false) // When selecting an existing chat, we're not in initial state
    },
    [setActiveChat, setIsInitialState],
  )

  // Handle new chat creation
  const handleNewChat = useCallback(() => {
    // Create a new chat and reset the UI to initial state
    createNewChat()
    setIsInitialState(true) // Force the UI to show the centered input
    return true
  }, [createNewChat, setIsInitialState])

  // Toggle sidebar
  const toggleSidebar = useCallback(() => {
    setIsSidebarOpen((prev) => !prev)
  }, [])

  return (
    <main className="min-h-screen bg-transparent text-black dark:text-white">
      {/* <BackgroundPattern /> */}
      <div className="relative z-10">
        <Header />
        <div className="pt-[31.347px]">
          <Sidebar
            className="top-[31.347px]"
            onClose={toggleSidebar}
            onChatSelect={handleChatSelect}
            chats={chats}
            setChats={setActiveChat}
            onToggleStar={toggleStarChat}
            onDeleteChat={deleteChat}
            onRename={updateChatName}
            isOpen={isSidebarOpen}
          />
          <div className={`transition-[margin] duration-300 ease-in-out relative ${isSidebarOpen ? "ml-80" : "ml-0"}`}>
            <ChatInterface
              isSidebarPinned={isSidebarOpen}
              selectedChat={activeChat}
              onNewMessage={handleNewMessage}
              handleReactionClick={handleReactionClick}
              handleFeedbackSubmit={handleFeedbackSubmit}
              handleFeedbackCancel={handleFeedbackCancel}
              toggleStarChat={toggleStarChat}
              createNewChat={handleNewChat}
              updateChatName={updateChatName}
              updateChatMachine={updateChatMachine}
              initialState={isInitialState}
              setIsInitialState={setIsInitialState}
              machines={MACHINES}
            />
          </div>
        </div>
      </div>
    </main>
  )
}

