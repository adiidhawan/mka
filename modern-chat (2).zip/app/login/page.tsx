"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useTheme } from "@/contexts/ThemeContext"
import { cn } from "@/lib/utils"
import { Eye, EyeOff, Mail, Lock } from "lucide-react"
import Image from "next/image"
import { AnimatedBackground } from "@/components/animated-background"
// Import the new LoginThemeToggle component
import { LoginThemeToggle } from "@/components/login-theme-toggle"

export default function LoginPage() {
  const router = useRouter()
  const { theme, toggleTheme } = useTheme()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate loading for a better UX
    setTimeout(() => {
      // For now, just redirect to the main app
      router.push("/chat")
    }, 1000)
  }

  return (
    <div
      className={cn(
        "min-h-screen flex flex-col",
        theme === "light" ? "bg-[#F0F8FF] text-gray-800" : "bg-[#141619] text-white",
      )}
    >
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Header */}
      <header className="relative z-10 flex justify-between items-center py-6 px-8">
        {/* Left logo */}
        <div className="flex items-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/TopSopt%20Logo%201-gV7FjZPnewnWKuvBF1pkxrvVb1RQm7.png"
            alt="TopSpot"
            width={120}
            height={40}
            className={theme === "dark" ? "opacity-90" : "opacity-100"}
          />
        </div>

        {/* Center title */}
        <h1 className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[27px] font-semibold tracking-tight">
          <span
            className={`relative bg-gradient-to-r from-[#4169E1] via-[#87CEFA] to-[#4169E1] bg-[400%_auto] animate-enhanced-flow bg-clip-text text-transparent transition-shadow duration-300 ${
              theme === "dark"
                ? "[text-shadow:0_1px_5px_rgba(65,105,225,0.2)]"
                : "[text-shadow:0_1px_5px_rgba(65,105,225,0.1)]"
            }`}
          >
            Maintenance Mitra
          </span>
        </h1>

        {/* Right logo */}
        <div className="flex items-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/TML%20Logo%201-Np8D8G5mmbZqj3yf9uroDoL8gDrhBo.png"
            alt="Tata Motors"
            width={160}
            height={75}
            className={theme === "dark" ? "opacity-90" : "opacity-100"}
          />
        </div>
      </header>

      {/* Login Form */}
      <main className="flex-1 flex items-center justify-center px-4 relative z-10">
        <div
          className={cn(
            "w-full max-w-md p-8 rounded-2xl shadow-xl backdrop-blur-sm border",
            theme === "light" ? "bg-white/90 border-gray-200" : "bg-[#1a2942]/90 border-gray-700",
          )}
        >
          <div className="text-center mb-8">
            <h1 className={cn("text-3xl font-bold", theme === "light" ? "text-gray-800" : "text-white")}>
              Welcome Back
            </h1>
            <p className={cn("mt-2", theme === "light" ? "text-gray-600" : "text-gray-300")}>
              Sign in to continue to Maintenance Mitra
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label
                htmlFor="email"
                className={cn("block text-sm font-medium", theme === "light" ? "text-gray-700" : "text-gray-200")}
              >
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className={theme === "light" ? "h-5 w-5 text-gray-500" : "h-5 w-5 text-gray-400"} />
                </div>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={cn(
                    "pl-10",
                    theme === "light"
                      ? "bg-gray-50 border-gray-300 focus:border-blue-400"
                      : "bg-[#1E2A45] border-gray-600 focus:border-blue-400",
                  )}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label
                htmlFor="password"
                className={cn("block text-sm font-medium", theme === "light" ? "text-gray-700" : "text-gray-200")}
              >
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className={theme === "light" ? "h-5 w-5 text-gray-500" : "h-5 w-5 text-gray-400"} />
                </div>
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={cn(
                    "pl-10 pr-10",
                    theme === "light"
                      ? "bg-gray-50 border-gray-300 focus:border-blue-400"
                      : "bg-[#1E2A45] border-gray-600 focus:border-blue-400",
                  )}
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={
                      theme === "light" ? "text-gray-500 hover:text-gray-700" : "text-gray-400 hover:text-gray-300"
                    }
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className={cn(
                    "h-4 w-4 rounded border focus:ring-blue-400 text-blue-500",
                    theme === "light" ? "border-gray-300 bg-gray-50" : "border-gray-600 bg-[#1E2A45]",
                  )}
                />
                <label
                  htmlFor="remember-me"
                  className={cn("ml-2 block text-sm", theme === "light" ? "text-gray-700" : "text-gray-300")}
                >
                  Remember me
                </label>
              </div>

              <div className="text-sm">
                <a
                  href="#"
                  className={cn("font-medium hover:underline", theme === "light" ? "text-blue-600" : "text-blue-400")}
                >
                  Forgot password?
                </a>
              </div>
            </div>

            <Button
              type="submit"
              className={cn(
                "w-full py-2.5 rounded-lg text-white transition-colors",
                "bg-[#C66A3F] hover:bg-[#B55A2F]",
                isLoading && "opacity-70 cursor-not-allowed",
              )}
              disabled={isLoading}
            >
              {isLoading ? "Signing in..." : "Sign in"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className={theme === "light" ? "text-gray-600" : "text-gray-300"}>
              Don't have an account?{" "}
              <a
                href="#"
                className={cn("font-medium hover:underline", theme === "light" ? "text-blue-600" : "text-blue-400")}
              >
                Sign up
              </a>
            </p>
          </div>
        </div>
      </main>

      {/* Theme Toggle */}
      <div className="fixed bottom-6 right-4 z-50">
        <LoginThemeToggle />
      </div>

      {/* Footer */}
      <footer className="relative z-10 py-6 text-center">
        <p className={theme === "light" ? "text-gray-600" : "text-gray-400"}>
          © {new Date().getFullYear()} Tata Motors. All rights reserved.
        </p>
      </footer>
    </div>
  )
}

