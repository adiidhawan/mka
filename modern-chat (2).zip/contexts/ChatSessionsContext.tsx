"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback } from "react"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

interface ChatSession {
  id: string
  name: string
  messages: Message[]
  createdAt: Date
  updatedAt: Date
}

interface ChatSessionsContextType {
  sessions: ChatSession[]
  currentSession: ChatSession | null
  createSession: (name: string) => void
  switchSession: (id: string) => void
  addMessage: (sessionId: string, content: string, role: "user" | "assistant") => void
  renameSession: (id: string, newName: string) => void
  deleteSession: (id: string) => void
}

const ChatSessionsContext = createContext<ChatSessionsContextType | undefined>(undefined)

export const useChatSessions = () => {
  const context = useContext(ChatSessionsContext)
  if (!context) {
    throw new Error("useChatSessions must be used within a ChatSessionsProvider")
  }
  return context
}

export const ChatSessionsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null)

  const createSession = useCallback((name: string) => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      name,
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    setSessions((prevSessions) => [...prevSessions, newSession])
    setCurrentSession(newSession)
  }, [])

  const switchSession = useCallback(
    (id: string) => {
      const session = sessions.find((s) => s.id === id)
      if (session) {
        setCurrentSession(session)
      }
    },
    [sessions],
  )

  const addMessage = useCallback((sessionId: string, content: string, role: "user" | "assistant") => {
    setSessions((prevSessions) =>
      prevSessions.map((session) => {
        if (session.id === sessionId) {
          const newMessage: Message = {
            id: Date.now().toString(),
            content,
            role,
            timestamp: new Date(),
          }
          return {
            ...session,
            messages: [...session.messages, newMessage],
            updatedAt: new Date(),
          }
        }
        return session
      }),
    )
  }, [])

  const renameSession = useCallback((id: string, newName: string) => {
    setSessions((prevSessions) =>
      prevSessions.map((session) => (session.id === id ? { ...session, name: newName } : session)),
    )
  }, [])

  const deleteSession = useCallback(
    (id: string) => {
      setSessions((prevSessions) => prevSessions.filter((session) => session.id !== id))
      if (currentSession?.id === id) {
        setCurrentSession(null)
      }
    },
    [currentSession],
  )

  return (
    <ChatSessionsContext.Provider
      value={{
        sessions,
        currentSession,
        createSession,
        switchSession,
        addMessage,
        renameSession,
        deleteSession,
      }}
    >
      {children}
    </ChatSessionsContext.Provider>
  )
}

