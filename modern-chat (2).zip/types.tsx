export interface ChatItem {
  id: string
  title: string
  date: Date
  isStarred: boolean
  messages?: Array<{ id: string; role: "user" | "assistant"; content: string }>
}

