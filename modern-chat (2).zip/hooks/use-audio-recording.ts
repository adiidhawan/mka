"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { apiService } from "@/utils/api"
import type { Message } from "@/types/chat"

interface SpeechRecognition extends EventTarget {
  continuous: boolean
  interimResults: boolean
  lang: string
  start: () => void
  stop: () => void
  abort: () => void
  onresult: (event: any) => void
  onerror: (event: any) => void
  onend: () => void
}

interface SpeechRecognitionEvent {
  resultIndex: number
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string
        confidence: number
      }
    }
    isFinal: boolean
  }
}

interface Window {
  SpeechRecognition: new () => SpeechRecognition
  webkitSpeechRecognition: new () => SpeechRecognition
}

type SetMessagesFunction = React.Dispatch<React.SetStateAction<Message[]>>

export function useAudioRecording(setMessages: SetMessagesFunction) {
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [audioData, setAudioData] = useState<Blob | null>(null)
  const [transcript, setTranscript] = useState("")
  const [isTranscribing, setIsTranscribing] = useState(false)

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  // Keep track of final transcript to avoid duplication
  const finalTranscriptRef = useRef("")
  const interimTranscriptRef = useRef("")

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }

      // Clean up media resources
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      // Clean up speech recognition
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  // Handle recording timer
  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1)
      }, 1000)
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
      setRecordingTime(0)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [isRecording])

  // Initialize speech recognition
  const initSpeechRecognition = useCallback(() => {
    // Check if browser supports speech recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition

    if (!SpeechRecognition) {
      console.error("Speech recognition not supported in this browser")
      return false
    }

    const recognition = new SpeechRecognition()
    recognitionRef.current = recognition

    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = "en-US"

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      // Reset interim transcript for this result batch
      interimTranscriptRef.current = ""

      // Process all results since last event
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript

        if (event.results[i].isFinal) {
          // Add to final transcript
          finalTranscriptRef.current += " " + transcript
        } else {
          // Add to interim transcript
          interimTranscriptRef.current += transcript
        }
      }

      // Trim any extra spaces
      finalTranscriptRef.current = finalTranscriptRef.current.trim()

      // Update the displayed transcript (final + current interim)
      setTranscript(
        finalTranscriptRef.current + (interimTranscriptRef.current ? " " + interimTranscriptRef.current : ""),
      )
    }

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error)
    }

    recognition.onend = () => {
      if (isRecording) {
        // Restart if we're still supposed to be recording
        recognition.start()
      } else {
        setIsTranscribing(false)
      }
    }

    return true
  }, [isRecording])

  // Start recording
  const startRecording = useCallback(async () => {
    try {
      // Reset transcripts when starting a new recording
      setTranscript("")
      finalTranscriptRef.current = ""
      interimTranscriptRef.current = ""

      // Request audio permission with constraints
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      })

      // Store stream for cleanup
      streamRef.current = stream

      // Create media recorder with optimized settings
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: "audio/webm;codecs=opus",
        audioBitsPerSecond: 128000, // 128kbps for better quality/size balance
      })

      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: "audio/webm;codecs=opus",
        })
        setAudioData(audioBlob)
      }

      // Start recording with a timeslice to get data more frequently
      mediaRecorder.start(1000)
      setIsRecording(true)

      // Start speech recognition for real-time transcription
      const recognitionInitialized = initSpeechRecognition()
      if (recognitionInitialized && recognitionRef.current) {
        setIsTranscribing(true)
        recognitionRef.current.start()
      }
    } catch (error) {
      console.error("Error accessing microphone:", error)
    }
  }, [initSpeechRecognition])

  // Stop recording
  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop()
      setIsRecording(false)

      // Stop all tracks to release the microphone
      if (mediaRecorderRef.current.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop())
      }
    }

    // Stop speech recognition
    if (recognitionRef.current) {
      recognitionRef.current.stop()
      setIsTranscribing(false)
    }

    // Make sure to include any interim results in the final transcript
    if (interimTranscriptRef.current) {
      finalTranscriptRef.current += " " + interimTranscriptRef.current
      finalTranscriptRef.current = finalTranscriptRef.current.trim()
      setTranscript(finalTranscriptRef.current)
      interimTranscriptRef.current = ""
    }
  }, [])

  // Cancel recording
  const cancelRecording = useCallback(() => {
    stopRecording()
    setAudioData(null)
    setTranscript("")
    finalTranscriptRef.current = ""
    interimTranscriptRef.current = ""
    audioChunksRef.current = []
  }, [stopRecording])

  // Handle recording submission
  const handleRecordingSubmit = useCallback(async () => {
    if (isRecording) {
      stopRecording()

      // Use the transcript we already have instead of sending to API
      if (transcript) {
        const newUserMessage: Message = {
          id: Date.now().toString(),
          role: "user",
          content: transcript,
          avatar: "U",
        }

        const newBotMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "...",
        }

        setMessages((prev) => [...prev, newUserMessage, newBotMessage])

        // Clean up
        setAudioData(null)
        setTranscript("")
        finalTranscriptRef.current = ""
        interimTranscriptRef.current = ""
        audioChunksRef.current = []
      } else {
        // Fallback to the old method if transcript is empty
        const audioBlob = new Blob(audioChunksRef.current, {
          type: "audio/webm;codecs=opus",
        })

        try {
          // Show a temporary message while processing
          const tempId = Date.now().toString()
          const processingMessage: Message = {
            id: tempId,
            role: "user",
            content: "Processing audio...",
            avatar: "U",
          }

          setMessages((prev) => [...prev, processingMessage])

          // Send the audio to the API for transcription
          const response = await apiService.speechToText(audioBlob)
          const transcribedText = response.data

          // Replace the temporary message with the transcribed text
          setMessages((prev) => {
            const updatedMessages = prev.filter((msg) => msg.id !== tempId)

            const newUserMessage: Message = {
              id: Date.now().toString(),
              role: "user",
              content: transcribedText,
              avatar: "U",
            }

            const newBotMessage: Message = {
              id: (Date.now() + 1).toString(),
              role: "assistant",
              content: "...",
            }

            return [...updatedMessages, newUserMessage, newBotMessage]
          })

          // Clean up
          setAudioData(null)
          audioChunksRef.current = []
        } catch (error) {
          console.error("Error transcribing audio:", error)

          // Show error message to user
          setMessages((prev) => {
            const errorMessage: Message = {
              id: Date.now().toString(),
              role: "assistant",
              content: "Sorry, I couldn't transcribe your audio. Please try again or type your message.",
            }
            return [...prev, errorMessage]
          })
        }
      }
    }
  }, [stopRecording, setMessages, transcript])

  return {
    isRecording,
    recordingTime,
    audioData,
    transcript,
    isTranscribing,
    startRecording,
    stopRecording,
    cancelRecording,
    handleRecordingSubmit,
  }
}

