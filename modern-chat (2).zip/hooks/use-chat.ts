"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { apiService } from "@/utils/api"
import { extractKeywords } from "@/utils/format"
import type { Message, Machine, ReactionState, ActiveFeedback } from "@/types/chat"

export interface ChatItem {
  id: string
  title: string
  date: Date
  isStarred: boolean
  messages: Message[]
  machines: Machine[] | []
}

export function useChat() {
  // State
  const [chats, setChats] = useState<ChatItem[]>([])
  const [activeChat, setActiveChat] = useState<ChatItem | null>(null)
  const [activeReactions, setActiveReactions] = useState<ReactionState>({})
  const [pendingReactions, setPendingReactions] = useState<ReactionState>({})
  const [temporaryActions, setTemporaryActions] = useState<Record<string, boolean>>({})
  const [activeFeedback, setActiveFeedback] = useState<ActiveFeedback | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isInitialState, setIsInitialState] = useState(true)

  // Refs to avoid unnecessary re-renders
  const chatsRef = useRef(chats)
  const activeChatRef = useRef(activeChat)

  // Keep refs in sync with state
  useEffect(() => {
    chatsRef.current = chats
  }, [chats])

  useEffect(() => {
    activeChatRef.current = activeChat
  }, [activeChat])

  // Create a new chat
  const createNewChat = useCallback((machine: Machine | null = null) => {
    const newChat: ChatItem = {
      id: Date.now().toString(),
      title: "New Chat",
      date: new Date(),
      isStarred: false,
      machines: machine ? [machine] : [],
      messages: [
        {
          id: "initial-message",
          role: "assistant",
          content: "Hi, I am Maintenance Mitra. How may I help you today?",
          isInitial: true,
        },
      ],
    }

    // Add the new chat to the beginning of the chats array
    setChats((prevChats) => [newChat, ...prevChats])

    // Set the new chat as active
    setActiveChat(newChat)

    // Reset to initial state when creating a new chat
    setIsInitialState(true)

    return newChat
  }, [])

  // Create initial chat when the hook is first used
  useEffect(() => {
    if (chats.length === 0) {
      createNewChat()
    }
  }, [createNewChat, chats.length])

  // Update chat name
  const updateChatName = useCallback(
    (chatId: string, newName: string) => {
      setChats((prevChats) => prevChats.map((chat) => (chat.id === chatId ? { ...chat, title: newName } : chat)))

      if (activeChat && activeChat.id === chatId) {
        setActiveChat((prevChat) => (prevChat ? { ...prevChat, title: newName } : null))
      }
    },
    [activeChat],
  )

  // Handle message submission
  const handleSubmit = useCallback(
    async (message: string, machine: Machine | null) => {
      if (!message.trim()) return

      setIsLoading(true)
      setError(null)
      setIsInitialState(false)

      // If there's no active chat, create a new one with the selected machine
      if (!activeChatRef.current) {
        const newChat = createNewChat(machine)
        handleMessageInChat(newChat.id, message, machine?.name || "")
        return
      }

      // Otherwise, add the message to the active chat
      // Use only the first machine (current machine) for the API call
      const currentMachine = activeChatRef.current.machines[0]
      handleMessageInChat(activeChatRef.current.id, message, currentMachine?.name || "")
    },
    [createNewChat],
  )

  // Helper function to handle adding a message to a specific chat
  const handleMessageInChat = async (chatId: string, message: string, machineName: string) => {
    // Find the chat by ID
    const chat = chatsRef.current.find((c) => c.id === chatId)
    if (!chat) {
      setError("Chat not found")
      setIsLoading(false)
      return
    }

    // Create the user message
    const newUserMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: message.trim(),
      machine: chat.machines[0] || null, // Store the current machine with the message
    }

    // Update the chat title if it's a new chat
    const newTitle = chat.title === "New Chat" ? extractKeywords(message) : chat.title

    // Update the chat with the user message
    const updatedChat = {
      ...chat,
      title: newTitle,
      date: new Date(), // Update timestamp
      messages: [...chat.messages, newUserMessage],
    }

    // Update the chats array
    setChats((prevChats) => prevChats.map((c) => (c.id === chatId ? updatedChat : c)))

    // Update the active chat if this is the active chat
    if (activeChatRef.current && activeChatRef.current.id === chatId) {
      setActiveChat(updatedChat)
    }

    // Add a temporary loading message
    const tempBotMessage: Message = {
      id: `temp-${Date.now()}`,
      role: "assistant",
      content: "Thinking...",
      isLoading: true,
      machine: chat.machines[0] || null,
    }

    // Update the chat with the temporary message
    const chatWithTempMessage = {
      ...updatedChat,
      messages: [...updatedChat.messages, tempBotMessage],
    }

    // Update the chats array with the temporary message
    setChats((prevChats) => prevChats.map((c) => (c.id === chatId ? chatWithTempMessage : c)))

    // Update the active chat if this is the active chat
    if (activeChatRef.current && activeChatRef.current.id === chatId) {
      setActiveChat(chatWithTempMessage)
    }

    try {
      // Get the response from the API with a longer timeout
      const response = await apiService.query(message, machineName)

      // Create the bot message
      const newBotMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.data.response || "Sorry, I couldn't generate a response.",
        machine: chat.machines[0] || null, // Store the current machine with the message
      }

      // Update the chat with the bot message (replacing the temporary message)
      const finalChat = {
        ...updatedChat,
        messages: [...updatedChat.messages, newBotMessage],
      }

      // Update the chats array
      setChats((prevChats) => prevChats.map((c) => (c.id === chatId ? finalChat : c)))

      // Update the active chat if this is the active chat
      if (activeChatRef.current && activeChatRef.current.id === chatId) {
        setActiveChat(finalChat)
      }
    } catch (err) {
      console.error("Error querying API:", err)

      // Determine if it's a timeout error
      const isTimeout =
        err.message &&
        (err.message.includes("timeout") || err.message.includes("ETIMEDOUT") || err.message.includes("ECONNABORTED"))

      const errorMessage = isTimeout
        ? "The server is taking too long to respond. Please try again later."
        : "Failed to get response from the server. Please try again."

      setError(errorMessage)

      // Replace the temporary message with an error message
      const errorBotMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: errorMessage,
        isError: true,
        machine: chat.machines[0] || null,
      }

      // Update the chat with the error message
      const chatWithErrorMessage = {
        ...updatedChat,
        messages: [...updatedChat.messages, errorBotMessage],
      }

      // Update the chats array
      setChats((prevChats) => prevChats.map((c) => (c.id === chatId ? chatWithErrorMessage : c)))

      // Update the active chat if this is the active chat
      if (activeChatRef.current && activeChatRef.current.id === chatId) {
        setActiveChat(chatWithErrorMessage)
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Handle reaction clicks
  const handleReactionClick = useCallback((msgId: string, reactionType: string, isActive: boolean) => {
    if (reactionType === "copy" || reactionType === "regenerate") {
      setTemporaryActions((prev) => ({
        ...prev,
        [`${msgId}-${reactionType}`]: true,
      }))

      setTimeout(() => {
        setTemporaryActions((prev) => ({
          ...prev,
          [`${msgId}-${reactionType}`]: false,
        }))
      }, 500)
    } else {
      if (isActive) {
        // Remove the reaction if it's already active
        setActiveReactions((prev) => {
          const newState = { ...prev }
          delete newState[msgId]
          return newState
        })

        setPendingReactions((prev) => {
          const newState = { ...prev }
          delete newState[msgId]
          return newState
        })

        setActiveFeedback(null)
      } else {
        setPendingReactions((prev) => {
          const currentReaction = prev[msgId]
          if (currentReaction === reactionType) {
            // If the same reaction is clicked again, remove it
            const newState = { ...prev }
            delete newState[msgId]
            return newState
          }
          // Otherwise, set the new reaction
          return { ...prev, [msgId]: reactionType }
        })

        // Set activeFeedback to show the feedback form
        const feedbackType = reactionType === "like" ? "good" : reactionType === "love" ? "great" : "bad"

        setActiveFeedback({
          messageId: msgId,
          type: feedbackType,
        })
      }
    }
  }, [])

  // Handle feedback submission
  const handleFeedbackSubmit = useCallback(
    async (data: { type: string; details: string; reasons: string[]; issueType?: string }) => {
      try {
        const score = data.type === "good" ? 4 : data.type === "great" ? 5 : data.type === "bad" ? 2 : 0

        await apiService.submitFeedback(
          "query123", // You might want to generate or track a unique run_id
          score,
          data.type,
          data.details,
        )

        console.log("Feedback submitted successfully")

        // Move pending reaction to active reactions
        if (activeFeedback) {
          setActiveReactions((prev) => ({
            ...prev,
            [activeFeedback.messageId]: pendingReactions[activeFeedback.messageId],
          }))

          setPendingReactions((prev) => {
            const newState = { ...prev }
            delete newState[activeFeedback.messageId]
            return newState
          })
        }

        setActiveFeedback(null)
      } catch (err) {
        console.error("Error submitting feedback:", err)
        setError("Failed to submit feedback. Please try again.")
      }
    },
    [activeFeedback, pendingReactions],
  )

  // Handle feedback cancellation
  const handleFeedbackCancel = useCallback(() => {
    if (activeFeedback) {
      setPendingReactions((prev) => {
        const newState = { ...prev }
        delete newState[activeFeedback.messageId]
        return newState
      })
    }
    setActiveFeedback(null)
  }, [activeFeedback])

  // Toggle star status for a chat
  const toggleStarChat = useCallback(
    (chatId: string) => {
      setChats((prevChats) =>
        prevChats.map((chat) => (chat.id === chatId ? { ...chat, isStarred: !chat.isStarred } : chat)),
      )

      if (activeChat && activeChat.id === chatId) {
        setActiveChat((prevChat) => (prevChat ? { ...prevChat, isStarred: !prevChat.isStarred } : null))
      }
    },
    [activeChat],
  )

  // Delete a chat
  const deleteChat = useCallback(
    (chatId: string) => {
      setChats((prevChats) => prevChats.filter((chat) => chat.id !== chatId))

      if (activeChat && activeChat.id === chatId) {
        setActiveChat(null)
        // Reset to initial state after deleting a chat
        setIsInitialState(true)
      }
    },
    [activeChat],
  )

  // Set active chat and update UI state
  const setActiveChatAndState = useCallback((chat: ChatItem | null) => {
    if (chat) {
      // Update the chat's date to ensure it's the most recent
      const updatedChat = {
        ...chat,
        date: new Date(), // Update to current time
      }

      // Update the chat in the chats array to ensure it appears at the top
      setChats((prevChats) => {
        // Remove the chat from the array
        const filteredChats = prevChats.filter((c) => c.id !== chat.id)
        // Add the updated chat at the beginning of the array
        return [updatedChat, ...filteredChats]
      })

      // Set the updated chat as active
      setActiveChat(updatedChat)
      setIsInitialState(false)
    } else {
      setActiveChat(null)
      setIsInitialState(true)
    }
  }, [])

  // Update machine for a chat
  const updateChatMachine = useCallback(
    (chatId: string, machine: Machine | null) => {
      // Update chats array
      setChats((prevChats) =>
        prevChats.map((chat) => {
          if (chat.id === chatId) {
            // If machine is null, clear the current machine but keep the history
            if (machine === null) {
              // Create a new array with the current machine removed
              return {
                ...chat,
                // Clear the current machine (first position)
                machines: chat.machines.length > 0 ? chat.machines.slice(1) : [],
              }
            }

            // Check if this machine already exists in the array
            const machineExists = chat.machines.some((m) => m.id === machine.id)

            if (machineExists) {
              // If it exists, move it to the first position (current machine)
              const updatedMachines = [machine, ...chat.machines.filter((m) => m.id !== machine.id)]
              return { ...chat, machines: updatedMachines }
            } else {
              // Add the new machine to the beginning of the array (current machine)
              return { ...chat, machines: [machine, ...chat.machines] }
            }
          }
          return chat
        }),
      )

      // Update active chat if it matches the chatId
      if (activeChat && activeChat.id === chatId) {
        setActiveChat((prevChat) => {
          if (!prevChat) return null

          // If machine is null, clear the current machine but keep the history
          if (machine === null) {
            // Create a new array with the current machine removed
            return {
              ...prevChat,
              // Clear the current machine (first position)
              machines: prevChat.machines.length > 0 ? prevChat.machines.slice(1) : [],
            }
          }

          // Check if this machine already exists in the array
          const machineExists = prevChat.machines.some((m) => m.id === machine.id)

          if (machineExists) {
            // If it exists, move it to the first position (current machine)
            const updatedMachines = [machine, ...prevChat.machines.filter((m) => m.id !== machine.id)]
            return { ...prevChat, machines: updatedMachines }
          } else {
            // Add the new machine to the beginning of the array (current machine)
            return { ...prevChat, machines: [machine, ...prevChat.machines] }
          }
        })
      }
    },
    [activeChat],
  )

  // Return all the necessary state and functions
  return {
    chats,
    activeChat,
    setActiveChat: setActiveChatAndState,
    createNewChat,
    updateChatName,
    messages: activeChat?.messages || [],
    handleSubmit,
    handleReactionClick,
    handleFeedbackSubmit,
    handleFeedbackCancel,
    activeReactions,
    pendingReactions,
    temporaryActions,
    activeFeedback,
    isLoading,
    error,
    toggleStarChat,
    deleteChat,
    isInitialState,
    setIsInitialState,
    setChats,
    updateChatMachine,
  }
}

