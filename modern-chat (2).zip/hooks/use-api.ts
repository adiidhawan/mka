"use client"

import { useState, useCallback } from "react"

export const useApi = () => {
    const [isLoading, setIsLoading] = useState(false)
    const [error, setError] = useState<Error | null>(null)

    const callApi = useCallback(async <T>(\
    apiMethod: (...args: any[]) => Promise<T>,
    ...args: any[]
  ): Promise<T | null> => {
    setIsLoading(true);
    setError(null)
    try {
      const result = await apiMethod(...args)
      return result
    } catch (err: any) {
      setError(err instanceof Error ? err : new Error(err.message || "An unknown error occurred"))
      return null
    } finally {
      setIsLoading(false)
    }
  },
  []
)

return { isLoading, error, callApi };
}

