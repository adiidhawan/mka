"use client"

import { useState, useCallback } from "react"
import { useChatSessions } from "@/contexts/ChatSessionsContext"

export const useChat = () => {
  const { sessions, currentSession, createSession, switchSession, addMessage, renameSession, deleteSession } =
    useChatSessions()

  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const sendMessage = useCallback(
    async (content: string) => {
      if (!currentSession) {
        setError("No active chat session")
        return
      }

      setIsLoading(true)
      setError(null)

      try {
        // Add user message
        addMessage(currentSession.id, content, "user")

        // Simulate API call for bot response
        await new Promise((resolve) => setTimeout(resolve, 1000))
        const botResponse = `This is a simulated response to: "${content}"`

        // Add bot message
        addMessage(currentSession.id, botResponse, "assistant")
      } catch (err) {
        setError("Failed to send message")
      } finally {
        setIsLoading(false)
      }
    },
    [currentSession, addMessage],
  )

  return {
    sessions,
    currentSession,
    isLoading,
    error,
    createSession,
    switchSession,
    sendMessage,
    renameSession,
    deleteSession,
  }
}

