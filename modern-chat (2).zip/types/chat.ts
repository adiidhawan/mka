export interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  isInitial?: boolean
  audioUrl?: string
  avatar?: string
  machine?: Machine | null // Add this field to track which machine the message is for
}

export interface Machine {
  id: string
  name: string
  icon?: string
  description?: string
}

export interface ChatItem {
  id: string
  title: string
  date: Date
  isStarred: boolean
  messages: Message[]
  machines: Machine[] | []
}

export interface ReactionState {
  [key: string]: string
}

export interface FeedbackData {
  type: string
  details: string
  reasons: string[]
  issueType?: string
}

export interface ActiveFeedback {
  messageId: string
  type: "good" | "great" | "bad"
}

